// No embedded data needed for this presentation
console.log('Presentation loaded - no external data dependencies');


const slidesData = [{"content":"<div class=\"slide title-slide\">\n  <style>\n    /* --- Title hero layout (scoped to this slide) --- */\n    .title-slide { padding: 6vh 6vw 5vh; }\n    .hero {\n      display: grid;\n      grid-template-columns: minmax(420px, 1.2fr) minmax(420px, .8fr);\n      align-items: center;\n      gap: clamp(24px, 5vw, 56px);\n      margin-top: 2vh;\n    }\n    .hero-left { display: grid; gap: clamp(8px, 1vw, 14px); }\n    .main-title {\n      font-size: clamp(44px, 6.2vw, 88px);\n      line-height: 1.05;\n      margin: 0;\n      margin-top: 0;\n      background: linear-gradient(180deg,#b8f5ff 0%, #29f5c8 60%, #1bd49a 100%);\n      -webkit-background-clip: text; background-clip: text; color: transparent;\n      text-shadow: 0 10px 40px rgba(0,0,0,.25);\n    }\n    .kicker {\n      margin: 0;\n      font-size: clamp(18px, 2.2vw, 26px);\n      font-weight: 600;\n      display: inline-flex; align-items: center; gap: .6em;\n    }\n    .kicker::before {\n      content: \"\"; width: .4em; height: 1.1em; border-radius: 2px; background: var(--accent2, #00e6a8);\n      box-shadow: 0 0 10px rgba(0,230,168,.4);\n    }\n\n    .hero-right svg { width: 100%; height: auto; display: block; }\n    .meta {\n      margin-top: clamp(24px, 4vh, 48px);\n      text-align: center;\n      display: grid;\n      gap: 8px;\n    }\n\n    /* tagline stays subtle */\n    .meta .tagline { opacity: .9; }\n\n    /* footer logo */\n    .meta-logo {\n      width: clamp(140px, 16vw, 240px);\n      height: auto;\n      margin: 10px auto 4px;\n      display: block;\n      filter: drop-shadow(0 8px 18px rgba(0, 255, 194, .15))\n              drop-shadow(0 2px 6px rgba(0, 0, 0, .35));\n      border-radius: 10px;\n    }\n\n    /* make \"Tech Talk\" larger and bolder */\n    .meta .talk {\n      font-size: clamp(36px, 5vw, 64px);\n      font-weight: 700;\n      letter-spacing: .5px;\n      opacity: .95;\n    }\n  </style>\n\n  <div class=\"hero\">\n    <div class=\"hero-left\">\n      <h1 class=\"main-title\">Stop Fighting Wraparound</h1>\n      <p class=\"kicker\">Embed Your Rings!</p>\n    </div>\n\n    <div class=\"hero-right\">\n      <!-- Bigger, cleaner SVG hero -->\n      <svg viewBox=\"0 0 460 300\">\n        <!-- circles -->\n        <circle cx=\"120\" cy=\"150\" r=\"95\" fill=\"none\" stroke=\"#4CAF50\" stroke-width=\"3\"/>\n        <circle cx=\"120\" cy=\"150\" r=\"65\" fill=\"none\" stroke=\"#4CAF50\" stroke-opacity=\".6\" stroke-width=\"3\"/>\n\n        <!-- wrong linear distance -->\n        <path d=\"M 185 150 L 55 150\" stroke=\"#FF5722\" stroke-width=\"2\" stroke-dasharray=\"6,6\" opacity=\"0.65\"/>\n        <text x=\"120\" y=\"137\" text-anchor=\"middle\" fill=\"#FFB74D\" font-weight=\"700\" font-size=\"16\">140° apart?</text>\n\n        <!-- correct arc distance -->\n        <path d=\"M 185 150 A 95 95 0 0 0 55 150\" fill=\"none\" stroke=\"#4CAF50\" stroke-width=\"3\"/>\n        <text x=\"120\" y=\"182\" text-anchor=\"middle\" fill=\"#9CFFB0\" font-weight=\"700\" font-size=\"16\">20° apart!</text>\n\n        <!-- endpoints (smaller bulbs) -->\n        <circle cx=\"185\" cy=\"150\" r=\"5\" fill=\"#FF5722\"/>\n        <circle cx=\"55\"  cy=\"150\" r=\"5\" fill=\"#2196F3\"/>\n\n        <!-- embed arrow/right panel -->\n        <path d=\"M 230 150 L 310 150\" stroke=\"#9aa4ad\" stroke-width=\"2\" marker-end=\"url(#arrowhead)\"/>\n        <text x=\"270\" y=\"136\" text-anchor=\"middle\" fill=\"#c9d1d9\" font-size=\"13\">embed</text>\n\n        <g transform=\"translate(360,150)\">\n          <line x1=\"-45\" y1=\"0\" x2=\"45\" y2=\"0\" stroke=\"#9aa4ad\" stroke-width=\"1\"/>\n          <line x1=\"0\" y1=\"-45\" x2=\"0\" y2=\"45\" stroke=\"#9aa4ad\" stroke-width=\"1\"/>\n          <circle cx=\"32\"  cy=\"0\" r=\"5\" fill=\"#FF5722\"/>\n          <circle cx=\"-32\" cy=\"0\" r=\"5\" fill=\"#2196F3\"/>\n          <text x=\"0\" y=\"-55\" text-anchor=\"middle\" fill=\"#c9d1d9\" font-size=\"12\">ℝ²</text>\n        </g>\n\n        <defs>\n          <marker id=\"arrowhead\" markerWidth=\"10\" markerHeight=\"7\" refX=\"10\" refY=\"3.5\" orient=\"auto\">\n            <polygon points=\"0 0, 10 3.5, 0 7\" fill=\"#9aa4ad\"/>\n          </marker>\n        </defs>\n      </svg>\n    </div>\n  </div>\n\n  <div class=\"meta\">\n    <p class=\"tagline\">A practical guide to handling ring-like quantities in code</p>\n\n    <!-- footer logo instead of the \"Ceres\" text -->\n    <img src=\"assets/_presentation_project_ceres-tech-logo.webp\" alt=\"Ceres AI\" class=\"meta-logo\" />\n\n    <p class=\"talk\">Tech Talk</p>\n  </div>\n</div>\n","title":"Stop Fighting Wraparound"},{"content":"<div class=\"slide\">\n    <h1>The Bug We've All Written</h1>\n    \n    <div class=\"highlight-box\">\n        <h3>❌ The Naive Approach</h3>\n        <pre><code class=\"language-python\">def average_angle(angle1, angle2):\n    return (angle1 + angle2) / 2  # Seems reasonable...\n\n# Example: Average heading between two compass readings\nheading1 = 350  # degrees\nheading2 = 10   # degrees\n\naverage = average_angle(heading1, heading2)\nprint(f\"Average: {average}°\")  # 180° - COMPLETELY WRONG!</code></pre>\n    </div>\n    \n    <div class=\"visual-demo\">\n        <svg width=\"600\" height=\"600\" viewBox=\"0 0 300 300\">\n            <!-- Compass circle -->\n            <circle cx=\"150\" cy=\"150\" r=\"120\" fill=\"none\" stroke=\"#333\" stroke-width=\"2\"/>\n            \n            <!-- Compass labels with stroke for better readability -->\n            <text x=\"150\" y=\"20\" text-anchor=\"middle\" font-size=\"16\" font-weight=\"bold\" fill=\"#FFC107\" paint-order=\"stroke\" stroke=\"#0b0f14\" stroke-width=\"3\">N (0°)</text>\n            <text x=\"280\" y=\"155\" text-anchor=\"middle\" font-size=\"16\" font-weight=\"bold\" fill=\"#FFC107\" paint-order=\"stroke\" stroke=\"#0b0f14\" stroke-width=\"3\">E (90°)</text>\n            <text x=\"150\" y=\"290\" text-anchor=\"middle\" font-size=\"16\" font-weight=\"bold\" fill=\"#FFC107\" paint-order=\"stroke\" stroke=\"#0b0f14\" stroke-width=\"3\">S (180°)</text>\n            <text x=\"20\" y=\"155\" text-anchor=\"middle\" font-size=\"16\" font-weight=\"bold\" fill=\"#FFC107\" paint-order=\"stroke\" stroke=\"#0b0f14\" stroke-width=\"3\">W (270°)</text>\n            \n            <!-- Heading 1: 350° -->\n            <line x1=\"150\" y1=\"150\" x2=\"140\" y2=\"30\" stroke=\"#2196F3\" stroke-width=\"4\"/>\n            <circle cx=\"140\" cy=\"30\" r=\"8\" fill=\"#2196F3\"/>\n            <text x=\"110\" y=\"20\" font-size=\"14\" fill=\"#FFC107\">350°</text>\n            \n            <!-- Heading 2: 10° -->\n            <line x1=\"150\" y1=\"150\" x2=\"160\" y2=\"30\" stroke=\"#4CAF50\" stroke-width=\"4\"/>\n            <circle cx=\"160\" cy=\"30\" r=\"8\" fill=\"#4CAF50\"/>\n            <text x=\"190\" y=\"20\" font-size=\"14\" fill=\"#FFC107\">10°</text>\n            \n            <!-- Wrong average: 180° -->\n            <line x1=\"150\" y1=\"150\" x2=\"150\" y2=\"270\" stroke=\"#FF5722\" stroke-width=\"4\" stroke-dasharray=\"5,5\"/>\n            <circle cx=\"150\" cy=\"270\" r=\"8\" fill=\"#FF5722\"/>\n            <text x=\"150\" y=\"260\" text-anchor=\"middle\" font-size=\"16\" fill=\"#FF5722\" font-weight=\"bold\">\n                Wrong: 180°\n            </text>\n            \n            <!-- Correct average indicator -->\n            <line x1=\"150\" y1=\"150\" x2=\"150\" y2=\"30\" stroke=\"#FFC107\" stroke-width=\"3\" opacity=\"0.7\"/>\n            <text x=\"220\" y=\"60\" font-size=\"14\" fill=\"#ffffff\" font-weight=\"bold\">Should be ~0°!</text>\n        </svg>\n    </div>\n    \n    <div class=\"warning-box\">\n        <h3>What Went Wrong?</h3>\n        <ul>\n            <li>350° and 10° are <strong>20° apart</strong> on the circle</li>\n            <li>But linear math sees them as <strong>340° apart</strong></li>\n            <li>The average points in the <strong>opposite direction</strong>!</li>\n        </ul>\n    </div>\n</div>\n\n<script>\n// Fix SVG layout and labels when this slide is displayed\nconsole.log('🎯 Slide 02-the-bug script executing');\nsetTimeout(() => {\n    console.log('🎯 Slide 02-the-bug timeout triggered');\n    const svg = document.querySelector('.visual-demo svg');\n    if (svg) {\n        console.log('   Found SVG in .visual-demo');\n        if (window.fixSVGLayoutAndLabels) {\n            console.log('   Calling fixSVGLayoutAndLabels from slide script');\n            window.fixSVGLayoutAndLabels(svg);\n        } else {\n            console.warn('   fixSVGLayoutAndLabels function not found on window');\n        }\n    } else {\n        console.warn('   No SVG found in .visual-demo');\n    }\n}, 100);\n</script>\n\n","title":"The Bug We've All Written"},{"content":"<div class=\"slide\">\n    <h1>The Midnight Bug</h1>\n    \n    <div class=\"info-box\">\n        <h3>📅 Real Scenario: Event Duration Tracking</h3>\n        <p>Meeting started at <strong>23:45</strong> (11:45 PM)</p>\n        <p>Meeting ended at <strong>00:15</strong> (12:15 AM)</p>\n    </div>\n    \n    <div class=\"code-comparison\">\n        <div class=\"highlight-box\">\n            <h4>❌ What Everyone Tries First</h4>\n            <pre><code>start_time = 23.75  # 23:45 in decimal hours\nend_time = 0.25     # 00:15 in decimal hours\n\nduration = end_time - start_time\nprint(f\"Duration: {duration} hours\")\n# Output: -23.5 hours 🤦</code></pre>\n        </div>\n        \n        <div class=\"warning-box\">\n            <h4>🤔 The Hacky \"Fix\"</h4>\n            <pre><code>if end_time < start_time:\n    # Must have crossed midnight\n    duration = (24 - start_time) + end_time\nelse:\n    duration = end_time - start_time\n    \n# More special cases...\nif crossed_dst:  # Daylight savings\n    duration += 1  # or -1? 😭</code></pre>\n        </div>\n    </div>\n    \n    <div class=\"clock-visual\">\n        <svg width=\"1200\" height=\"500\" viewBox=\"0 0 800 300\">\n            <!-- Linear representation -->\n            <g transform=\"translate(30, 80)\">\n                <text x=\"150\" y=\"-20\" text-anchor=\"middle\" font-size=\"14\" font-weight=\"bold\" fill=\"#FFC107\">Linear View:</text>\n                <line x1=\"0\" y1=\"20\" x2=\"300\" y2=\"20\" stroke=\"#333\" stroke-width=\"2\"/>\n                \n                <!-- Time markers -->\n                <line x1=\"0\" y1=\"15\" x2=\"0\" y2=\"25\" stroke=\"#333\" stroke-width=\"2\"/>\n                <text x=\"0\" y=\"40\" text-anchor=\"middle\" font-size=\"12\" fill=\"#FFC107\">0:00</text>\n                \n                <line x1=\"150\" y1=\"15\" x2=\"150\" y2=\"25\" stroke=\"#333\" stroke-width=\"2\"/>\n                <text x=\"150\" y=\"40\" text-anchor=\"middle\" font-size=\"12\" fill=\"#FFC107\">12:00</text>\n                \n                <line x1=\"300\" y1=\"15\" x2=\"300\" y2=\"25\" stroke=\"#333\" stroke-width=\"2\"/>\n                <text x=\"300\" y=\"40\" text-anchor=\"middle\" font-size=\"12\" fill=\"#FFC107\">24:00</text>\n                \n                <!-- Start time: 23:45 (23.75/24 * 300 = 296.25) -->\n                <circle cx=\"296\" cy=\"20\" r=\"8\" fill=\"#2196F3\"/>\n                <text x=\"296\" y=\"60\" text-anchor=\"middle\" font-size=\"12\" fill=\"#FFC107\">23:45</text>\n                \n                <!-- End time: 00:15 (0.25/24 * 300 = 3.125) -->\n                <circle cx=\"3\" cy=\"20\" r=\"8\" fill=\"#4CAF50\"/>\n                <text x=\"3\" y=\"60\" text-anchor=\"middle\" font-size=\"12\" fill=\"#FFC107\">00:15</text>\n                \n                <!-- Wrong distance -->\n                <path d=\"M 296 20 L 3 20\" stroke=\"#FF5722\" stroke-width=\"2\" stroke-dasharray=\"5,5\" opacity=\"0.5\"/>\n                <text x=\"150\" y=\"80\" text-anchor=\"middle\" fill=\"#FF5722\" font-size=\"14\">Linear: -23.5 hours!</text>\n            </g>\n            \n            <!-- Circular representation -->\n            <g transform=\"translate(550, 150)\">\n                <text x=\"0\" y=\"-90\" text-anchor=\"middle\" font-size=\"14\" font-weight=\"bold\" fill=\"#FFC107\">Circular View:</text>\n                <circle cx=\"0\" cy=\"0\" r=\"70\" fill=\"none\" stroke=\"#333\" stroke-width=\"2\"/>\n                \n                <!-- Clock numbers -->\n                <text x=\"0\" y=\"-55\" text-anchor=\"middle\" font-size=\"12\" fill=\"#FFC107\">12</text>\n                <text x=\"55\" y=\"5\" text-anchor=\"middle\" font-size=\"12\" fill=\"#FFC107\">3</text>\n                <text x=\"0\" y=\"60\" text-anchor=\"middle\" font-size=\"12\" fill=\"#FFC107\">6</text>\n                <text x=\"-55\" y=\"5\" text-anchor=\"middle\" font-size=\"12\" fill=\"#FFC107\">9</text>\n                \n                <!-- Start: 23:45 -->\n                <line x1=\"0\" y1=\"0\" x2=\"-10\" y2=\"-68\" stroke=\"#2196F3\" stroke-width=\"3\"/>\n                <circle cx=\"-10\" cy=\"-68\" r=\"8\" fill=\"#2196F3\"/>\n                \n                <!-- End: 00:15 -->\n                <line x1=\"0\" y1=\"0\" x2=\"10\" y2=\"-68\" stroke=\"#4CAF50\" stroke-width=\"3\"/>\n                <circle cx=\"10\" cy=\"-68\" r=\"8\" fill=\"#4CAF50\"/>\n                \n                <!-- Correct arc -->\n                <path d=\"M -10 -68 A 70 70 0 0 1 10 -68\" fill=\"none\" stroke=\"#4CAF50\" stroke-width=\"3\"/>\n                <text x=\"0\" y=\"90\" text-anchor=\"middle\" fill=\"#4CAF50\" font-size=\"14\" font-weight=\"bold\">\n                    Correct: 30 minutes!\n                </text>\n            </g>\n        </svg>\n    </div>\n    \n    <div class=\"success-box\">\n        <h3>💡 The Key Insight</h3>\n        <p>Time-of-day is a <strong>24-hour ring</strong>, not a line!</p>\n        <p>Linear arithmetic breaks at the wraparound point.</p>\n    </div>\n</div>\n\n","title":"The Midnight Bug"},{"content":"<div class=\"slide\">\n    <h1>The Missing Math Class: Circular Operations</h1>\n    \n    <div class=\"warning-box\">\n        <h3>🤯 What They Never Taught You</h3>\n        <p>Circular quantities are everywhere, but traditional math classes skip the operations entirely! Here's what you can actually <strong>do</strong> once you embed them as vectors:</p>\n    </div>\n    \n    <div class=\"two-column-equal\">\n        <div class=\"card\">\n            <h3>📊 Basic Operations</h3>\n            <div class=\"operation-list\">\n                <div class=\"op-item\">\n                    <strong>Addition:</strong> <code>v₁ + v₂</code><br>\n                    <small>Compose two rotations</small>\n                </div>\n                <div class=\"op-item\">\n                    <strong>Subtraction:</strong> <code>v₁ - v₂</code><br>\n                    <small>Find angular difference</small>\n                </div>\n                <div class=\"op-item\">\n                    <strong>Average:</strong> <code>mean(vectors)</code><br>\n                    <small>Circular mean (always works!)</small>\n                </div>\n                <div class=\"op-item\">\n                    <strong>Interpolation:</strong> <code>slerp(v₁, v₂, t)</code><br>\n                    <small>Smooth rotation between angles</small>\n                </div>\n            </div>\n        </div>\n        \n        <div class=\"card\">\n            <h3>🧮 Advanced Operations</h3>\n            <div class=\"operation-list\">\n                <div class=\"op-item\">\n                    <strong>Distance:</strong> <code>shortest_path(θ₁, θ₂)</code><br>\n                    <small>Minimal angular separation</small>\n                </div>\n                <div class=\"op-item\">\n                    <strong>Scaling:</strong> <code>scalar × vector</code><br>\n                    <small>Scale magnitude, preserve direction</small>\n                </div>\n                <div class=\"op-item\">\n                    <strong>Derivatives:</strong> <code>d/dt [cos(ωt), sin(ωt)]</code><br>\n                    <small>Angular velocity vectors</small>\n                </div>\n                <div class=\"op-item\">\n                    <strong>Integration:</strong> <code>∫ ω(t) dt</code><br>\n                    <small>Accumulate rotations over time</small>\n                </div>\n            </div>\n        </div>\n    </div>\n    \n    <div class=\"success-box\">\n        <h3>📈 Circular Statistics (The Really Cool Stuff)</h3>\n        <div class=\"code-example\">\n            <pre><code class=\"language-python\"># Operations that actually work on circular data!\nangles = [350°, 10°, 5°, 355°]  # Wind directions\nvectors = [to_vector(θ) for θ in angles]\n\n# Circular mean (not 180°!)\nmean_vector = np.mean(vectors, axis=0) \nmean_angle = from_vector(mean_vector)  # ≈ 0°\n\n# Circular standard deviation  \ndispersion = 1 - |mean_vector|  # How \"spread out\" are they?\n\n# Circular correlation\ncorrelation = correlate_circular(wind_dir, wave_dir)\n\n# Circular regression (yes, this exists!)\nslope, intercept = circular_regression(time, wave_directions)</code></pre>\n        </div>\n    </div>\n    \n    <div class=\"info-box\">\n        <h3>🎯 Why This Matters</h3>\n        <div class=\"three-column\">\n            <div>\n                <h4>🌊 Oceanography</h4>\n                <p>Wave directions, current flows</p>\n            </div>\n            <div>\n                <h4>🧭 Navigation</h4>\n                <p>GPS, compass bearings, flight paths</p>\n            </div>\n            <div>\n                <h4>🧬 Biology</h4>\n                <p>Circadian rhythms, animal migration</p>\n            </div>\n            <div>\n                <h4>🎵 Signal Processing</h4>\n                <p>Phase analysis, Fourier transforms</p>\n            </div>\n            <div>\n                <h4>🤖 Robotics</h4>\n                <p>Joint angles, orientation control</p>\n            </div>\n            <div>\n                <h4>📊 Data Science</h4>\n                <p>Seasonal trends, cyclic patterns</p>\n            </div>\n        </div>\n    </div>\n    \n    <div class=\"highlight-box\">\n        <h3>💡 The Big Insight</h3>\n        <p><strong>Every operation you know from linear algebra works on circular quantities—you just need to embed them first!</strong> This is why embedding is such a powerful mathematical technique.</p>\n        <div class=\"formula-showcase\">\n            <code>Circular Quantity → Vector → Linear Operation → Vector → Circular Result</code>\n        </div>\n    </div>\n</div>","title":"The Missing Math Class: Circular Operations"},{"content":"<div class=\"slide\">\n    <h1>Circular Statistics: The Hidden Superpower</h1>\n    \n    <div class=\"warning-box\">\n        <h3>🤯 What Statistics Class Never Taught You</h3>\n        <p>Standard statistics breaks horribly on circular data. But vector embedding makes circular statistics <strong>trivially easy</strong>—and incredibly powerful!</p>\n    </div>\n    \n    <div class=\"two-column-equal\">\n        <div class=\"card\">\n            <h3>📊 The Problem with Regular Stats</h3>\n            <div class=\"code-example\">\n                <pre><code class=\"language-python\"># Wind directions (degrees)\nangles = [350, 10, 5, 355]\n\n# Regular mean = DISASTER\nmean = sum(angles) / len(angles)  # = 180°\n# 180° is the OPPOSITE direction! 🤦‍♂️\n\n# Regular standard deviation = MEANINGLESS\nstd = numpy.std(angles)  # = 187°\n# Standard deviation larger than the range!</code></pre>\n            </div>\n        </div>\n        \n        <div class=\"card\">\n            <h3>✨ Vector Statistics = Magic</h3>\n            <div class=\"code-example\">\n                <pre><code class=\"language-python\"># Convert to vectors\nvectors = [angle_to_vector(θ) for θ in angles]\n\n# Circular mean = WORKS!\nmean_vector = np.mean(vectors, axis=0)\nmean_angle = vector_to_angle(mean_vector)  # ≈ 0°\n# Correct direction! 🎯\n\n# Circular standard deviation\nR = |mean_vector|  # Mean vector length\ncircular_std = sqrt(-2 * log(R))  # ≈ 22°\n# Sensible measure of spread!</code></pre>\n            </div>\n        </div>\n    </div>\n    \n    <div class=\"info-box\">\n        <h3>🧠 The Key Insight: Mean Vector Length</h3>\n        <div class=\"two-column\">\n            <div class=\"visual-element\">\n                <svg width=\"300\" height=\"200\" viewBox=\"0 0 300 200\">\n                    <!-- Tight cluster -->\n                    <g transform=\"translate(75, 100)\">\n                        <circle r=\"50\" fill=\"none\" stroke=\"#666\" stroke-width=\"1\" opacity=\"0.3\"/>\n                        <!-- Data points clustered tightly -->\n                        <circle cx=\"45\" cy=\"5\" r=\"4\" fill=\"#4CAF50\"/>\n                        <circle cx=\"47\" cy=\"-3\" r=\"4\" fill=\"#4CAF50\"/>\n                        <circle cx=\"43\" cy=\"3\" r=\"4\" fill=\"#4CAF50\"/>\n                        <circle cx=\"46\" cy=\"0\" r=\"4\" fill=\"#4CAF50\"/>\n                        <!-- Strong mean vector -->\n                        <path d=\"M 0 0 L 40 0\" stroke=\"#FF5722\" stroke-width=\"4\" marker-end=\"url(#arrow)\"/>\n                        <text x=\"0\" y=\"-65\" text-anchor=\"middle\" fill=\"#4CAF50\" font-size=\"12\">Tight Cluster</text>\n                        <text x=\"0\" y=\"75\" text-anchor=\"middle\" fill=\"#FF5722\" font-size=\"11\">|R| ≈ 0.95</text>\n                        <text x=\"0\" y=\"87\" text-anchor=\"middle\" fill=\"#666\" font-size=\"10\">Low variance</text>\n                    </g>\n                    \n                    <!-- Spread out data -->\n                    <g transform=\"translate(225, 100)\">\n                        <circle r=\"50\" fill=\"none\" stroke=\"#666\" stroke-width=\"1\" opacity=\"0.3\"/>\n                        <!-- Data points spread out -->\n                        <circle cx=\"45\" cy=\"5\" r=\"4\" fill=\"#2196F3\"/>\n                        <circle cx=\"-30\" cy=\"35\" r=\"4\" fill=\"#2196F3\"/>\n                        <circle cx=\"-15\" cy=\"-45\" r=\"4\" fill=\"#2196F3\"/>\n                        <circle cx=\"20\" cy=\"-40\" r=\"4\" fill=\"#2196F3\"/>\n                        <!-- Weak mean vector -->\n                        <path d=\"M 0 0 L 8 -5\" stroke=\"#FF5722\" stroke-width=\"4\" marker-end=\"url(#arrow)\"/>\n                        <text x=\"0\" y=\"-65\" text-anchor=\"middle\" fill=\"#2196F3\" font-size=\"12\">Spread Out</text>\n                        <text x=\"0\" y=\"75\" text-anchor=\"middle\" fill=\"#FF5722\" font-size=\"11\">|R| ≈ 0.1</text>\n                        <text x=\"0\" y=\"87\" text-anchor=\"middle\" fill=\"#666\" font-size=\"10\">High variance</text>\n                    </g>\n                    \n                    <defs>\n                        <marker id=\"arrow\" markerWidth=\"10\" markerHeight=\"7\" refX=\"10\" refY=\"3.5\" orient=\"auto\">\n                            <polygon points=\"0 0, 10 3.5, 0 7\" fill=\"#FF5722\"/>\n                        </marker>\n                    </defs>\n                </svg>\n            </div>\n            <div>\n                <h4>💡 The Beautiful Truth</h4>\n                <div class=\"formula-showcase\">\n                    <p><strong>Tight cluster:</strong> Mean vector is long (|R| → 1)</p>\n                    <p><strong>Spread out:</strong> Mean vector is short (|R| → 0)</p>\n                    <p><strong>Uniform circle:</strong> Mean vector ≈ 0</p>\n                </div>\n                <p>The length of the mean vector automatically captures how \"concentrated\" your circular data is!</p>\n            </div>\n        </div>\n    </div>\n    \n    <div class=\"success-box\">\n        <h3>🔬 Advanced Circular Stats That Actually Work</h3>\n        <div class=\"code-example\">\n            <pre><code class=\"language-python\"># Circular correlation between two angular variables\ndef circular_correlation(angles1, angles2):\n    v1 = [angle_to_vector(θ) for θ in angles1]\n    v2 = [angle_to_vector(θ) for θ in angles2]\n    # Standard correlation on the vector components\n    return pearsonr(v1, v2)\n\n# Circular regression (yes, this exists!)\ndef circular_regression(x, circular_y):\n    vectors_y = [angle_to_vector(θ) for θ in circular_y]\n    # Regress each component separately\n    cos_model = LinearRegression().fit(x, [v[0] for v in vectors_y])\n    sin_model = LinearRegression().fit(x, [v[1] for v in vectors_y])\n    return cos_model, sin_model\n\n# Watson-Williams test (circular ANOVA)\n# Test if multiple groups have the same mean direction\ndef watson_williams_test(group1_angles, group2_angles):\n    # Convert to vectors, compute mean directions, test significance\n    # (This is the circular equivalent of a t-test!)</code></pre>\n        </div>\n    </div>\n    \n    <div class=\"highlight-box\">\n        <h3>🌟 Real-World Applications</h3>\n        <div class=\"three-column\">\n            <div>\n                <h4>🧬 Biology</h4>\n                <p><strong>Animal migration:</strong> Test if birds change direction by season</p>\n                <p><strong>Circadian rhythms:</strong> Correlate activity with time of day</p>\n            </div>\n            <div>\n                <h4>🌊 Earth Sciences</h4>\n                <p><strong>Wind patterns:</strong> Seasonal wind direction changes</p>\n                <p><strong>Ocean currents:</strong> Correlation with tidal cycles</p>\n            </div>\n            <div>\n                <h4>🎵 Signal Processing</h4>\n                <p><strong>Phase analysis:</strong> Correlation between signal phases</p>\n                <p><strong>Circular convolution:</strong> Periodic signal filtering</p>\n            </div>\n        </div>\n    </div>\n</div>","title":"Circular Statistics: The Hidden Superpower"},{"content":"<div class=\"slide\">\n    <h1>Discrete Calculus on Circles: Data-Driven Operations</h1>\n    \n    <div class=\"info-box\">\n        <h3>📊 Real-World Data = Discrete Samples</h3>\n        <p>In practice, we don't have continuous functions—we have <strong>time series data</strong> of circular quantities. How do we compute derivatives and integrals when our data wraps around?</p>\n    </div>\n    \n    <div class=\"two-column-equal\">\n        <div class=\"card\">\n            <h3>📈 Discrete Derivatives (Angular Velocity)</h3>\n            <div class=\"code-example\">\n                <pre><code class=\"language-python\"># WRONG: Naive difference breaks at wraparound\nangles = [358°, 359°, 1°, 2°]  # Smooth rotation\nnaive_diff = [1°, 2°, -357°]  # HUGE SPIKE! 💥\n\n# RIGHT: Vector space derivative\nvectors = [(cos(θ), sin(θ)) for θ in angles]\ndvdt = [(v[i+1] - v[i])/dt for i in range(len(v)-1)]\n\n# Angular velocity from vector derivative\nω = cross_product(v[i], dvdt[i]) / |v[i]|²\n# Result: [1°/s, 1°/s, 1°/s] ✅</code></pre>\n            </div>\n        </div>\n        \n        <div class=\"card\">\n            <h3>📉 Discrete Integrals (Accumulated Rotation)</h3>\n            <div class=\"code-example\">\n                <pre><code class=\"language-python\"># WRONG: Sum angles directly\nangular_velocities = [90°/s, 90°/s, 90°/s, 90°/s]\nnaive_sum = sum(angular_velocities) * dt  # 360°???\n\n# RIGHT: Accumulate in vector space\nv_accumulated = [1, 0]  # Start at 0°\nfor ω in angular_velocities:\n    # Rotate vector by angular increment\n    dθ = ω * dt\n    rotation = [[cos(dθ), -sin(dθ)],\n                [sin(dθ), cos(dθ)]]\n    v_accumulated = rotation @ v_accumulated\n\nfinal_angle = atan2(v_accumulated)  # Correct!</code></pre>\n            </div>\n        </div>\n    </div>\n    \n    <div class=\"success-box\">\n        <h3>🔧 Practical Applications in Data Science</h3>\n        <div class=\"two-column\">\n            <div>\n                <h4>🌊 Wind Speed Analysis</h4>\n                <div class=\"code-example\">\n                    <pre><code class=\"language-python\"># Wind direction time series (sampled every hour)\nwind_dirs = [350°, 355°, 0°, 5°, 10°]  # North-ish\nwind_speeds = [10, 12, 15, 14, 11]  # mph\n\n# Compute wind vector components\nu = [-speed * sin(dir) for speed, dir in zip(wind_speeds, wind_dirs)]\nv = [-speed * cos(dir) for speed, dir in zip(wind_speeds, wind_dirs)]\n\n# Now can compute proper derivatives!\ndu_dt = np.gradient(u)  # Wind acceleration (east)\ndv_dt = np.gradient(v)  # Wind acceleration (north)</code></pre>\n                </div>\n            </div>\n            <div>\n                <h4>🤖 Robot Heading Tracking</h4>\n                <div class=\"code-example\">\n                    <pre><code class=\"language-python\"># IMU gives heading samples at 100Hz\nheadings = sensor.get_heading_buffer()  # [θ₁, θ₂, ..., θₙ]\ndt = 0.01  # 10ms between samples\n\n# Convert to unit vectors\nvectors = [(cos(h), sin(h)) for h in headings]\n\n# Compute angular velocity using discrete derivative\nangular_vel = []\nfor i in range(len(vectors)-1):\n    # Cross product gives rotation rate\n    ω = (vectors[i][0]*vectors[i+1][1] - \n         vectors[i][1]*vectors[i+1][0]) / dt\n    angular_vel.append(ω)\n\n# Smooth using windowed average (no wraparound issues!)\nsmoothed_ω = moving_average(angular_vel, window=10)</code></pre>\n                </div>\n            </div>\n        </div>\n    </div>\n    \n    <div class=\"warning-box\">\n        <h3>⚠️ Common Pitfalls with Discrete Circular Data</h3>\n        <div class=\"three-column\">\n            <div>\n                <h4>❌ Phase Unwrapping</h4>\n                <p><code>unwrap([350°, 10°])</code> → <code>[350°, 370°]</code></p>\n                <p>Creates artificial trends! Use vectors instead.</p>\n            </div>\n            <div>\n                <h4>❌ Modulo Arithmetic</h4>\n                <p><code>(θ₂ - θ₁) % 360</code></p>\n                <p>Loses direction info. Vector difference preserves it.</p>\n            </div>\n            <div>\n                <h4>❌ Averaging Raw Angles</h4>\n                <p><code>mean([0°, 90°, 180°, 270°])</code> → <code>135°</code></p>\n                <p>Should be undefined! Vector mean → 0.</p>\n            </div>\n        </div>\n    </div>\n    \n    <div class=\"highlight-box\">\n        <h3>🎯 The Key Pattern for Discrete Operations</h3>\n        <div class=\"formula-showcase\">\n            <div style=\"text-align: center; padding: 20px;\">\n                <p style=\"font-size: 18px; margin: 10px 0;\">\n                    <strong>Discrete Samples</strong> → <strong>Vector Time Series</strong> → <strong>Standard Numpy Operations</strong> → <strong>Interpret Results</strong>\n                </p>\n                <p style=\"margin-top: 20px;\">\n                    <code>θ[t]</code> → <code>[cos(θ[t]), sin(θ[t])]</code> → <code>np.gradient(), np.cumsum()</code> → <code>atan2() if needed</code>\n                </p>\n            </div>\n        </div>\n        <p><strong>Bottom Line:</strong> NumPy/Pandas operations \"just work\" on vector representations—no special circular functions needed!</p>\n    </div>\n</div>","title":"Discrete Calculus on Circles: Data-Driven Operations"},{"content":"<div class=\"slide\">\n    <h1>Hidden Rings Everywhere: Beyond Angles & Time</h1>\n    \n    <div class=\"warning-box\">\n        <h3>🔍 Circular Quantities Hide in Plain Sight</h3>\n        <p>It's not just angles, time, and colors that wrap around. Here are the sneaky cyclic variables that cause bugs when you least expect them:</p>\n    </div>\n    \n    <div class=\"pattern-table\">\n        <table style=\"width: 100%; border-collapse: collapse;\">\n            <thead>\n                <tr style=\"background: rgba(33, 150, 243, 0.1); border-bottom: 2px solid #2196F3;\">\n                    <th style=\"padding: 12px; text-align: left; width: 30%;\">Domain</th>\n                    <th style=\"padding: 12px; text-align: left; width: 35%;\">❌ Where Naive Math Fails</th>\n                    <th style=\"padding: 12px; text-align: left; width: 35%;\">✅ Correct Embedding</th>\n                </tr>\n            </thead>\n            <tbody>\n                <tr style=\"border-bottom: 1px solid #444;\">\n                    <td style=\"padding: 10px;\"><strong>📅 Weekdays</strong><br><code>d ∈ {0..6}</code></td>\n                    <td style=\"padding: 10px;\">Mean of Sat(6) and Mon(1) = 3.5 (Wed)?<br><span style=\"color: #FF5722;\">Wrong! Should be Sunday</span></td>\n                    <td style=\"padding: 10px;\"><code>(cos(2πd/7), sin(2πd/7))</code></td>\n                </tr>\n                <tr style=\"border-bottom: 1px solid #444; background: rgba(255, 255, 255, 0.02);\">\n                    <td style=\"padding: 10px;\"><strong>🔧 Rotary Encoders</strong><br><code>n ∈ [0, 4096)</code></td>\n                    <td style=\"padding: 10px;\">4095 → 1 looks like −4094 ticks<br><span style=\"color: #FF5722;\">Actually just 2 ticks forward!</span></td>\n                    <td style=\"padding: 10px;\"><code>(cos(2πn/N), sin(2πn/N))</code></td>\n                </tr>\n                <tr style=\"border-bottom: 1px solid #444;\">\n                    <td style=\"padding: 10px;\"><strong>🌍 Longitude</strong><br><code>λ ∈ [−180°, 180°)</code></td>\n                    <td style=\"padding: 10px;\">Mean of 179°E and 179°W = 0°?<br><span style=\"color: #FF5722;\">Points are 2° apart, not at Greenwich!</span></td>\n                    <td style=\"padding: 10px;\">3D vectors on sphere:<br><code>(cos(lat)cos(lon), cos(lat)sin(lon), sin(lat))</code></td>\n                </tr>\n                <tr style=\"border-bottom: 1px solid #444; background: rgba(255, 255, 255, 0.02);\">\n                    <td style=\"padding: 10px;\"><strong>📡 Signal Phase</strong><br><code>φ ∈ [−π, π)</code></td>\n                    <td style=\"padding: 10px;\">Phase unwrapping creates artificial jumps<br><span style=\"color: #FF5722;\">Destroys true periodicity</span></td>\n                    <td style=\"padding: 10px;\">Complex: <code>e<sup>iφ</sup> = cos(φ) + i·sin(φ)</code></td>\n                </tr>\n                <tr style=\"border-bottom: 1px solid #444;\">\n                    <td style=\"padding: 10px;\"><strong>💍 Ring Buffers</strong><br><code>idx ∈ [0, size)</code></td>\n                    <td style=\"padding: 10px;\"><code>tail - head</code> wrong when wrapped<br><span style=\"color: #FF5722;\">Buffer looks full when nearly empty!</span></td>\n                    <td style=\"padding: 10px;\"><code>(idx + size) % size</code><br>or embed as angle</td>\n                </tr>\n                <tr style=\"border-bottom: 1px solid #444; background: rgba(255, 255, 255, 0.02);\">\n                    <td style=\"padding: 10px;\"><strong>⚙️ Gear Teeth</strong><br><code>tooth ∈ [0, N)</code></td>\n                    <td style=\"padding: 10px;\">Tooth 0 and Tooth N-1 look maximally apart<br><span style=\"color: #FF5722;\">They're actually neighbors!</span></td>\n                    <td style=\"padding: 10px;\"><code>(cos(2πt/N), sin(2πt/N))</code></td>\n                </tr>\n                <tr style=\"border-bottom: 1px solid #444;\">\n                    <td style=\"padding: 10px;\"><strong>🧬 Circadian Phase</strong><br><code>t ∈ [0, 24h)</code></td>\n                    <td style=\"padding: 10px;\">Sleep at 23:00 and 01:00 averages to noon?<br><span style=\"color: #FF5722;\">Should be midnight!</span></td>\n                    <td style=\"padding: 10px;\"><code>(cos(2πt/24), sin(2πt/24))</code></td>\n                </tr>\n                <tr style=\"border-bottom: 1px solid #444; background: rgba(255, 255, 255, 0.02);\">\n                    <td style=\"padding: 10px;\"><strong>📊 Months of Year</strong><br><code>m ∈ {1..12}</code></td>\n                    <td style=\"padding: 10px;\">Dec(12) to Jan(1) = -11 months?<br><span style=\"color: #FF5722;\">Just 1 month forward!</span></td>\n                    <td style=\"padding: 10px;\"><code>(cos(2πm/12), sin(2πm/12))</code></td>\n                </tr>\n            </tbody>\n        </table>\n    </div>\n    \n    <div class=\"highlight-box\">\n        <h3>💡 The Universal Solution</h3>\n        <div class=\"formula-showcase\">\n            <p style=\"text-align: center; font-size: 18px; margin: 15px 0;\">\n                <strong>For ANY cyclic quantity with period T starting at offset s:</strong>\n            </p>\n            <p style=\"text-align: center; font-size: 20px; background: rgba(76, 175, 80, 0.1); padding: 15px; border-radius: 8px;\">\n                <code>θ = 2π(value - s)/T</code> → <code>(cos(θ), sin(θ))</code>\n            </p>\n            <p style=\"text-align: center; margin-top: 15px;\">\n                Do all your math in vector space, then project back if needed!\n            </p>\n        </div>\n    </div>\n    \n    <div class=\"info-box\">\n        <h3>🎯 When to Suspect a Hidden Ring</h3>\n        <div class=\"two-column\">\n            <div>\n                <h4>🚩 Red Flags in Your Data</h4>\n                <ul>\n                    <li>Values that \"roll over\" or \"wrap\"</li>\n                    <li>Modulo operations in the code</li>\n                    <li>Special cases for \"crossing midnight\"</li>\n                    <li>Discontinuous jumps in time series</li>\n                    <li>\"Distance\" that depends on direction</li>\n                </ul>\n            </div>\n            <div>\n                <h4>🐛 Classic Bug Patterns</h4>\n                <ul>\n                    <li>Averages that are wildly wrong</li>\n                    <li>Interpolation that takes the \"long way\"</li>\n                    <li>Derivatives with impossible spikes</li>\n                    <li>Sorting that puts neighbors far apart</li>\n                    <li>Clustering that splits natural groups</li>\n                </ul>\n            </div>\n        </div>\n    </div>\n</div>","title":"Hidden Rings Everywhere: Beyond Angles & Time"},{"content":"<div class=\"slide\">\n    <h1>When Zero Isn't Special: Arbitrary Wrap Points</h1>\n    \n    <div class=\"warning-box\">\n        <h3>🎯 Real Hardware Doesn't Care About Zero</h3>\n        <p>Many circular quantities in the wild wrap at arbitrary values, not nice round numbers. The math still works—you just need to normalize first!</p>\n    </div>\n    \n    <div class=\"two-column-equal\">\n        <div class=\"card\">\n            <h3>📊 Common Non-Zero Wrap Domains</h3>\n            <div class=\"example-list\">\n                <div class=\"example-item\">\n                    <h4>🧭 Compass: [-180°, +180°)</h4>\n                    <p>Wraps at ±180°, not 0°/360°</p>\n                    <code>bearing ∈ [-180, 180)</code>\n                </div>\n                <div class=\"example-item\">\n                    <h4>🔧 Rotary Encoder: [1000, 5096)</h4>\n                    <p>12-bit encoder with arbitrary offset</p>\n                    <code>counts ∈ [1000, 5096)</code>\n                </div>\n                <div class=\"example-item\">\n                    <h4>📡 Phase: [-π, +π)</h4>\n                    <p>Centered around zero, not starting at it</p>\n                    <code>phase ∈ [-π, π)</code>\n                </div>\n                <div class=\"example-item\">\n                    <h4>🗓️ Fiscal Year: [Apr, Mar]</h4>\n                    <p>Wraps at March/April boundary</p>\n                    <code>month ∈ [4, 3] (mod 12)</code>\n                </div>\n                <div class=\"example-item\">\n                    <h4>🌡️ ADC Values: [512, 3584)</h4>\n                    <p>Sensor with DC offset and limited range</p>\n                    <code>adc ∈ [512, 3584)</code>\n                </div>\n            </div>\n        </div>\n        \n        <div class=\"card\">\n            <h3>✨ The Universal Transform</h3>\n            <div class=\"formula-showcase\" style=\"background: rgba(76, 175, 80, 0.1); padding: 20px; border-radius: 8px; margin: 20px 0;\">\n                <h4>For any circular quantity:</h4>\n                <p><code>value ∈ [min, max)</code></p>\n                <p style=\"margin: 15px 0;\">↓</p>\n                <p><strong>1. Normalize to [0, 1):</strong></p>\n                <p><code>t = (value - min) / (max - min)</code></p>\n                <p style=\"margin: 15px 0;\">↓</p>\n                <p><strong>2. Embed on unit circle:</strong></p>\n                <p><code>v = (cos(2πt), sin(2πt))</code></p>\n                <p style=\"margin: 15px 0;\">↓</p>\n                <p><strong>3. Do your math in ℝ²</strong></p>\n                <p style=\"margin: 15px 0;\">↓</p>\n                <p><strong>4. Project back if needed:</strong></p>\n                <p><code>result = min + (max-min) × atan2(v.y, v.x)/(2π)</code></p>\n            </div>\n        </div>\n    </div>\n    \n    <div class=\"success-box\">\n        <h3>💻 Code Example: Averaging Compass Bearings</h3>\n        <div class=\"code-example\">\n            <pre><code class=\"language-python\"># PROBLEM: Compass uses [-180°, +180°) not [0°, 360°)\nbearings = [170, 175, -175, -170]  # All pointing roughly south\n\n# WRONG: Simple average\nnaive_mean = np.mean(bearings)  # = 0° (North!) 🤦\n\n# RIGHT: Normalize → Embed → Average → Denormalize\ndef circular_mean(values, min_val, max_val):\n    # Step 1: Normalize to [0, 1)\n    period = max_val - min_val\n    normalized = [(v - min_val) / period for v in values]\n    \n    # Step 2: Embed on circle\n    vectors = [(np.cos(2*np.pi*t), np.sin(2*np.pi*t)) for t in normalized]\n    \n    # Step 3: Average in vector space\n    mean_vector = np.mean(vectors, axis=0)\n    \n    # Step 4: Project back to original domain\n    angle = np.atan2(mean_vector[1], mean_vector[0])\n    result = min_val + (angle / (2*np.pi)) * period\n    if result < min_val:\n        result += period\n    return result\n\ncorrect_mean = circular_mean(bearings, -180, 180)  # ≈ 175° South! ✅</code></pre>\n        </div>\n    </div>\n    \n    <div class=\"info-box\">\n        <h3>🔧 Practical Examples</h3>\n        <div class=\"three-column\">\n            <div>\n                <h4>🎮 Game Development</h4>\n                <div class=\"code-snippet\">\n                    <pre><code># Joystick angle ∈ [-π, π]\njs_angle = atan2(js.y, js.x)\n# Don't compare directly!\n# Normalize first</code></pre>\n                </div>\n            </div>\n            <div>\n                <h4>🤖 Robotics</h4>\n                <div class=\"code-snippet\">\n                    <pre><code># Encoder wraps at 8192\n# but starts at 1000\nactual_pos = 1000 + \n  (raw - 1000) % 7192</code></pre>\n                </div>\n            </div>\n            <div>\n                <h4>📊 Time Series</h4>\n                <div class=\"code-snippet\">\n                    <pre><code># Fiscal quarters Q2-Q1\n# April = month 0\nfiscal_month = \n  (cal_month - 4) % 12</code></pre>\n                </div>\n            </div>\n        </div>\n    </div>\n    \n    <div class=\"highlight-box\">\n        <h3>🎯 Key Insight</h3>\n        <p style=\"font-size: 18px; text-align: center; margin: 20px 0;\">\n            <strong>The \"zero point\" is arbitrary!</strong> What matters is the <em>topology</em>—that values wrap around.\n        </p>\n        <p style=\"text-align: center;\">\n            Always normalize to [0, 1) or [0, 2π) before embedding. Your vector math doesn't care where the original wrap point was.\n        </p>\n    </div>\n</div>","title":"When Zero Isn't Special: Arbitrary Wrap Points"},{"content":"<div class=\"slide\">\n    <h1>Real Example: Robot/Drone Heading Control</h1>\n    \n    <div class=\"problem-setup\">\n        <h3>🤖 The Scenario</h3>\n        <p>PID controller needs to turn robot from 350° to 10°</p>\n    </div>\n    \n    <div class=\"visual-comparison\">\n        <div class=\"approach bad-approach\">\n            <h4>❌ Naive PID Error</h4>\n            <svg width=\"500\" height=\"500\" viewBox=\"0 0 250 250\">\n                <circle cx=\"125\" cy=\"125\" r=\"100\" fill=\"none\" stroke=\"#333\" stroke-width=\"2\"/>\n                \n                <!-- Current heading: 350° -->\n                <line x1=\"125\" y1=\"125\" x2=\"115\" y2=\"25\" stroke=\"#2196F3\" stroke-width=\"4\"/>\n                <circle cx=\"115\" cy=\"25\" r=\"6\" fill=\"#2196F3\"/>\n                <text x=\"75\" y=\"15\" font-size=\"12\" fill=\"#FFC107\">Current: 350°</text>\n                \n                <!-- Target heading: 10° -->\n                <line x1=\"125\" y1=\"125\" x2=\"135\" y2=\"25\" stroke=\"#4CAF50\" stroke-width=\"4\"/>\n                <circle cx=\"135\" cy=\"25\" r=\"6\" fill=\"#4CAF50\"/>\n                <text x=\"175\" y=\"15\" font-size=\"12\" fill=\"#FFC107\">Target: 10°</text>\n                \n                <!-- Wrong rotation path -->\n                <path d=\"M 115 25 A 100 100 0 1 1 135 25\" fill=\"none\" stroke=\"#FF5722\" stroke-width=\"3\" stroke-dasharray=\"5,5\"/>\n                <text x=\"125\" y=\"200\" text-anchor=\"middle\" font-size=\"14\" fill=\"#FF5722\" font-weight=\"bold\">\n                    Error: -340°\n                </text>\n                <text x=\"125\" y=\"220\" text-anchor=\"middle\" font-size=\"12\" fill=\"#FF5722\">\n                    Spins backward!\n                </text>\n            </svg>\n            \n            <pre><code>error = target - current\nerror = 10 - 350 = -340°\n# Robot spins almost full circle\n# the wrong way!</code></pre>\n        </div>\n        \n        <div class=\"approach good-approach\">\n            <h4>✅ Embedded Solution</h4>\n            <svg width=\"500\" height=\"500\" viewBox=\"0 0 250 250\">\n                <circle cx=\"125\" cy=\"125\" r=\"100\" fill=\"none\" stroke=\"#333\" stroke-width=\"2\"/>\n                \n                <!-- Current heading: 350° -->\n                <line x1=\"125\" y1=\"125\" x2=\"115\" y2=\"25\" stroke=\"#2196F3\" stroke-width=\"4\"/>\n                <circle cx=\"115\" cy=\"25\" r=\"6\" fill=\"#2196F3\"/>\n                <text x=\"75\" y=\"15\" font-size=\"12\" fill=\"#FFC107\">Current: 350°</text>\n                \n                <!-- Target heading: 10° -->\n                <line x1=\"125\" y1=\"125\" x2=\"135\" y2=\"25\" stroke=\"#4CAF50\" stroke-width=\"4\"/>\n                <circle cx=\"135\" cy=\"25\" r=\"6\" fill=\"#4CAF50\"/>\n                <text x=\"175\" y=\"15\" font-size=\"12\" fill=\"#FFC107\">Target: 10°</text>\n                \n                <!-- Correct rotation path -->\n                <path d=\"M 115 25 A 100 100 0 0 1 135 25\" fill=\"none\" stroke=\"#4CAF50\" stroke-width=\"3\"/>\n                <text x=\"125\" y=\"200\" text-anchor=\"middle\" font-size=\"14\" fill=\"#4CAF50\" font-weight=\"bold\">\n                    Error: +20°\n                </text>\n                <text x=\"125\" y=\"220\" text-anchor=\"middle\" font-size=\"12\" fill=\"#4CAF50\">\n                    Efficient turn!\n                </text>\n            </svg>\n            \n            <pre><code>def heading_error(current, target):\n    c_vec = [cos(current), sin(current)]\n    t_vec = [cos(target), sin(target)]\n    return atan2(cross(c_vec, t_vec), \n                 dot(c_vec, t_vec))\n# Returns: +20° (shortest path!)</code></pre>\n        </div>\n    </div>\n    \n    <div class=\"implementation\">\n        <h3>Complete PID Controller Fix</h3>\n        <pre><code class=\"language-python\">class HeadingController:\n    def __init__(self, kp=1.0, ki=0.1, kd=0.05):\n        self.kp, self.ki, self.kd = kp, ki, kd\n        self.integral = 0\n        self.last_error = 0\n        \n    def compute_control(self, current_heading, target_heading, dt):\n        # Embed both headings as vectors\n        current_vec = np.array([np.cos(current_heading), np.sin(current_heading)])\n        target_vec = np.array([np.cos(target_heading), np.sin(target_heading)])\n        \n        # Compute signed angle error (always shortest path)\n        error = np.arctan2(\n            current_vec[0] * target_vec[1] - current_vec[1] * target_vec[0],\n            current_vec[0] * target_vec[0] + current_vec[1] * target_vec[1]\n        )\n        \n        # Standard PID computation (now with correct error!)\n        self.integral += error * dt\n        derivative = (error - self.last_error) / dt\n        \n        control = self.kp * error + self.ki * self.integral + self.kd * derivative\n        self.last_error = error\n        \n        return control  # Angular velocity command</code></pre>\n    </div>\n    \n    <div class=\"impact-note\">\n        <p>💰 <strong>Real Impact:</strong> Shipping routes crossing the Pacific get drawn spanning ~359° longitude instead of the short ~20 nautical mile path due to antimeridian wraparound bugs in mapping SDKs</p>\n    </div>\n</div>\n\n","title":"Real Example: Robot/Drone Heading Control"},{"content":"<div class=\"slide color-interpolation\">\n  <style>\n    /* Scoped styles for color interpolation slide */\n    .color-interpolation {\n      padding: 2vh 3vw;\n      display: flex;\n      flex-direction: column;\n      gap: 1.5vh;\n    }\n\n    .color-interpolation h1 {\n      font-size: clamp(24px, 3vw, 40px);\n      margin: 0 0 1vh 0;\n      text-align: center;\n      background: linear-gradient(135deg, #ff6b6b, #4ecdc4);\n      -webkit-background-clip: text;\n      background-clip: text;\n      color: transparent;\n    }\n\n    .color-interpolation .card {\n      background: rgba(255, 255, 255, 0.04);\n      border: 1px solid rgba(255, 255, 255, 0.09);\n      border-radius: 14px;\n      padding: 14px 16px;\n      margin-bottom: 1vh;\n    }\n\n    .color-interpolation .drag-wrap {\n      display: grid;\n      grid-template-columns: 420px 1fr;\n      gap: 28px;\n      align-items: start;\n      flex: 1;\n    }\n\n    @media (max-width: 960px) {\n      .color-interpolation .drag-wrap {\n        grid-template-columns: 1fr;\n      }\n    }\n\n    .color-interpolation .drag-wheel {\n      position: relative;\n      width: 400px;\n      height: 400px;\n      margin: 0 auto;\n    }\n\n    .color-interpolation .drag-wheel .wheel {\n      position: absolute;\n      inset: 0;\n      border-radius: 50%;\n      /* Red at North: default starting position is top */\n      background: conic-gradient(\n        hsl(0, 100%, 50%),\n        hsl(60, 100%, 50%),\n        hsl(120, 100%, 50%),\n        hsl(180, 100%, 50%),\n        hsl(240, 100%, 50%),\n        hsl(300, 100%, 50%),\n        hsl(360, 100%, 50%)\n      );\n      box-shadow: 0 10px 26px rgba(0, 0, 0, 0.35);\n    }\n\n    /* Concentric inner mask to make a neat ring (no offset) */\n    .color-interpolation .drag-wheel .mask {\n      position: absolute;\n      inset: 42px;\n      background: #0b1117;\n      border-radius: 50%;\n      box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.08);\n      pointer-events: none;\n    }\n\n    .color-interpolation .drag-wheel svg {\n      position: absolute;\n      inset: 0;\n      overflow: visible;\n    }\n\n    .color-interpolation .legend2 {\n      display: grid;\n      gap: 8px;\n      color: #cfe0f1;\n      font-size: 14px;\n    }\n\n    .color-interpolation .chip-row {\n      display: flex;\n      gap: 14px;\n      align-items: center;\n      flex-wrap: wrap;\n    }\n\n    .color-interpolation .chip {\n      display: inline-flex;\n      align-items: center;\n      gap: 8px;\n      padding: 6px 10px;\n      border: 1px solid rgba(255, 255, 255, 0.12);\n      border-radius: 10px;\n      background: rgba(255, 255, 255, 0.02);\n    }\n\n    .color-interpolation .dot {\n      width: 12px;\n      height: 12px;\n      border-radius: 50%;\n      display: inline-block;\n      box-shadow: 0 0 0 2px rgba(0, 0, 0, 0.35) inset;\n    }\n\n    .color-interpolation .mono {\n      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas,\n        \"Liberation Mono\", monospace;\n    }\n\n    .color-interpolation .midbars {\n      display: grid;\n      gap: 8px;\n      margin-top: 10px;\n    }\n\n    .color-interpolation .midbars .bar {\n      height: 18px;\n      border: 1px solid rgba(255, 255, 255, 0.12);\n      border-radius: 10px;\n    }\n  </style>\n\n  <h1>Drag the Hues on the Wheel</h1>\n\n  <div class=\"card\">\n    <p>\n      Drag the two handles <strong>A</strong> and <strong>B</strong> on the hue\n      wheel. The vectors are colored by their hues. We show two \"midpoints\": the\n      <strong>correct circular midpoint</strong> (shortest arc,\n      <code>t=0.5</code>) and the <strong>naive linear midpoint</strong> (just\n      averaging numbers). Watch how naive linear often cuts through unrelated\n      hues.\n    </p>\n  </div>\n\n  <div class=\"drag-wrap\">\n    <div class=\"drag-wheel\" aria-label=\"Hue wheel with draggable handles\">\n      <div class=\"wheel\"></div>\n      <div class=\"mask\"></div>\n      <svg id=\"dwSVG\" viewBox=\"0 0 400 400\" width=\"400\" height=\"400\">\n        <defs>\n          <filter id=\"vec-shadow\">\n            <feDropShadow\n              dx=\"0\"\n              dy=\"1\"\n              stdDeviation=\"1.2\"\n              flood-color=\"#000\"\n              flood-opacity=\".65\"\n            />\n          </filter>\n        </defs>\n        <!-- guide ring -->\n        <circle\n          cx=\"200\"\n          cy=\"200\"\n          r=\"179\"\n          fill=\"none\"\n          stroke=\"rgba(255,255,255,.22)\"\n          stroke-width=\"1\"\n        />\n        <!-- arc between A and B (shortest arc) -->\n        <path\n          id=\"dwArc\"\n          d=\"\"\n          fill=\"none\"\n          stroke=\"#FFD180\"\n          stroke-width=\"5\"\n          stroke-linecap=\"round\"\n          stroke-dasharray=\"6,7\"\n          opacity=\".9\"\n        />\n        <!-- vectors -->\n        <g id=\"vecA\" filter=\"url(#vec-shadow)\">\n          <line\n            id=\"lineA\"\n            x1=\"200\"\n            y1=\"200\"\n            x2=\"200\"\n            y2=\"42\"\n            stroke=\"#fff\"\n            stroke-width=\"7\"\n          />\n          <circle\n            id=\"handleA\"\n            cx=\"200\"\n            cy=\"42\"\n            r=\"9\"\n            fill=\"#fff\"\n            stroke=\"rgba(0,0,0,.5)\"\n            stroke-width=\"2\"\n          />\n          <text\n            id=\"labelA\"\n            x=\"200\"\n            y=\"28\"\n            text-anchor=\"middle\"\n            fill=\"#e6eef9\"\n            font-size=\"13\"\n          >\n            A\n          </text>\n        </g>\n        <g id=\"vecB\" filter=\"url(#vec-shadow)\">\n          <line\n            id=\"lineB\"\n            x1=\"200\"\n            y1=\"200\"\n            x2=\"200\"\n            y2=\"42\"\n            stroke=\"#fff\"\n            stroke-width=\"7\"\n          />\n          <circle\n            id=\"handleB\"\n            cx=\"200\"\n            cy=\"42\"\n            r=\"9\"\n            fill=\"#fff\"\n            stroke=\"rgba(0,0,0,.5)\"\n            stroke-width=\"2\"\n          />\n          <text\n            id=\"labelB\"\n            x=\"200\"\n            y=\"28\"\n            text-anchor=\"middle\"\n            fill=\"#e6eef9\"\n            font-size=\"13\"\n          >\n            B\n          </text>\n        </g>\n        <!-- correct midpoint vector -->\n        <g id=\"vecMid\" filter=\"url(#vec-shadow)\">\n          <line\n            id=\"lineMid\"\n            x1=\"200\"\n            y1=\"200\"\n            x2=\"200\"\n            y2=\"42\"\n            stroke=\"#fff\"\n            stroke-width=\"7\"\n          />\n          <circle\n            id=\"handleMid\"\n            cx=\"200\"\n            cy=\"42\"\n            r=\"9\"\n            fill=\"#fff\"\n            stroke=\"rgba(0,0,0,.5)\"\n            stroke-width=\"2\"\n          />\n          <text\n            id=\"labelMid\"\n            x=\"200\"\n            y=\"28\"\n            text-anchor=\"middle\"\n            fill=\"#e6eef9\"\n            font-size=\"13\"\n          >\n            circular mid\n          </text>\n        </g>\n        <!-- naive midpoint vector -->\n        <g id=\"vecNaive\" filter=\"url(#vec-shadow)\">\n          <line\n            id=\"lineNaive\"\n            x1=\"200\"\n            y1=\"200\"\n            x2=\"200\"\n            y2=\"42\"\n            stroke=\"#fff\"\n            stroke-width=\"5\"\n            stroke-dasharray=\"4,6\"\n          />\n          <circle\n            id=\"handleNaive\"\n            cx=\"200\"\n            cy=\"42\"\n            r=\"7\"\n            fill=\"#fff\"\n            stroke=\"rgba(0,0,0,.5)\"\n            stroke-width=\"2\"\n          />\n          <text\n            id=\"labelNaive\"\n            x=\"200\"\n            y=\"28\"\n            text-anchor=\"middle\"\n            fill=\"#e6eef9\"\n            font-size=\"12\"\n          >\n            naive mid\n          </text>\n        </g>\n      </svg>\n    </div>\n\n    <div class=\"legend2\">\n      <div class=\"chip-row\">\n        <div class=\"chip\">\n          <span class=\"dot\" id=\"dotA\"></span>\n          <span class=\"mono\">A: <span id=\"degA\">0°</span></span>\n        </div>\n        <div class=\"chip\">\n          <span class=\"dot\" id=\"dotB\"></span>\n          <span class=\"mono\">B: <span id=\"degB\">0°</span></span>\n        </div>\n        <div class=\"chip\">\n          <span class=\"dot\" id=\"dotMid\"></span>\n          <span class=\"mono\"\n            >Circular mid (t=0.5): <span id=\"degMid\">0°</span></span\n          >\n        </div>\n        <div class=\"chip\">\n          <span class=\"dot\" id=\"dotNaive\"></span>\n          <span class=\"mono\">Naive mid: <span id=\"degNaive\">0°</span></span>\n        </div>\n      </div>\n      <div class=\"midbars\">\n        <div class=\"bar\" id=\"barCircular\" title=\"Circular midpoint path\"></div>\n        <small>\n          Correct (circular): follows the shorter arc between A and B.\n        </small>\n        <div class=\"bar\" id=\"barNaive\" title=\"Naive midpoint colors\"></div>\n        <small>\n          Naive (linear hue numbers): can jump across unrelated hues.\n        </small>\n      </div>\n    </div>\n  </div>\n</div>\n","title":"Drag the Hues on the Wheel"},{"content":"<div class=\"slide\">\n    <h1>The General Pattern</h1>\n    \n    <div class=\"pattern-table\">\n        <h3>Any Circular Quantity Can Be Embedded!</h3>\n        <table>\n            <thead>\n                <tr>\n                    <th>Wraparound Quantity</th>\n                    <th>Traditional Problems</th>\n                    <th>Embedding Solution</th>\n                    <th>Benefits</th>\n                </tr>\n            </thead>\n            <tbody>\n                <tr>\n                    <td><strong>Angle</strong><br>θ ∈ [0, 2π)</td>\n                    <td>Gimbal lock, discontinuities</td>\n                    <td>(cos θ, sin θ) ∈ ℝ²</td>\n                    <td>Smooth interpolation</td>\n                </tr>\n                <tr>\n                    <td><strong>Time of Day</strong><br>t ∈ [0, 24)</td>\n                    <td>Midnight wraparound</td>\n                    <td>(cos 2πt/24, sin 2πt/24)</td>\n                    <td>No special cases</td>\n                </tr>\n                <tr>\n                    <td><strong>Day of Week</strong><br>d ∈ {0..6}</td>\n                    <td>Weekend averaging</td>\n                    <td>e^(2πid/7) or 7D one-hot</td>\n                    <td>Correct statistics</td>\n                </tr>\n                <tr>\n                    <td><strong>Phase</strong><br>φ ∈ [-π, π)</td>\n                    <td>Phase unwrapping</td>\n                    <td>e^(iφ) ∈ ℂ</td>\n                    <td>Natural operations</td>\n                </tr>\n                <tr>\n                    <td><strong>Encoder Position</strong><br>n ∈ [0, 4096)</td>\n                    <td>Rollover detection</td>\n                    <td>(cos 2πn/4096, sin 2πn/4096)</td>\n                    <td>Continuous tracking</td>\n                </tr>\n            </tbody>\n        </table>\n    </div>\n    \n    <div class=\"universal-class\">\n        <h3>One Class to Rule Them All</h3>\n        <pre><code class=\"language-python\">class CircularQuantity:\n    \"\"\"Universal handler for any quantity that wraps around\"\"\"\n    \n    def __init__(self, value, period):\n        self.period = period\n        self.value = value % period  # Normalize to [0, period)\n        \n        # THE KEY: Embed on unit circle\n        theta = 2 * np.pi * self.value / period\n        self.vec = np.array([np.cos(theta), np.sin(theta)])\n    \n    def shortest_distance_to(self, other):\n        \"\"\"Always returns shortest signed distance\"\"\"\n        angle = np.arctan2(\n            self.vec[0] * other.vec[1] - self.vec[1] * other.vec[0],\n            self.vec[0] * other.vec[0] + self.vec[1] * other.vec[1]\n        )\n        return angle * self.period / (2 * np.pi)\n    \n    def average_with(self, others):\n        \"\"\"Proper circular mean\"\"\"\n        all_vecs = [self.vec] + [o.vec for o in others]\n        mean_vec = np.mean(all_vecs, axis=0)\n        mean_vec /= np.linalg.norm(mean_vec)  # Renormalize\n        \n        angle = np.arctan2(mean_vec[1], mean_vec[0])\n        mean_value = angle * self.period / (2 * np.pi)\n        return CircularQuantity(mean_value, self.period)\n    \n    def interpolate_to(self, other, t):\n        \"\"\"Smooth interpolation along shortest path\"\"\"\n        # SLERP for perfect circular interpolation\n        dot = np.dot(self.vec, other.vec)\n        omega = np.arccos(np.clip(dot, -1, 1))\n        \n        if abs(omega) < 1e-10:  # Vectors are identical\n            return self\n        \n        vec_t = (np.sin((1-t)*omega)/np.sin(omega) * self.vec +\n                 np.sin(t*omega)/np.sin(omega) * other.vec)\n        \n        angle = np.arctan2(vec_t[1], vec_t[0])\n        value = angle * self.period / (2 * np.pi)\n        return CircularQuantity(value, self.period)</code></pre>\n    </div>\n    \n    <div class=\"examples-grid\">\n        <div class=\"example\">\n            <h4>📐 Angles</h4>\n            <pre><code>a1 = CircularQuantity(350, 360)\na2 = CircularQuantity(10, 360)\ndist = a1.shortest_distance_to(a2)\n# Result: 20°</code></pre>\n        </div>\n        \n        <div class=\"example\">\n            <h4>⏰ Time</h4>\n            <pre><code>t1 = CircularQuantity(23.5, 24)\nt2 = CircularQuantity(0.5, 24)\navg = t1.average_with([t2])\n# Result: 0.0 (midnight)</code></pre>\n        </div>\n        \n        <div class=\"example\">\n            <h4>📅 Weekdays</h4>\n            <pre><code>days = [CircularQuantity(6, 7),  # Sat\n        CircularQuantity(0, 7),  # Sun\n        CircularQuantity(1, 7)]  # Mon\navg = days[0].average_with(days[1:])\n# Result: 0 (Sunday)</code></pre>\n        </div>\n        \n        <div class=\"example\">\n            <h4>🔄 Encoder</h4>\n            <pre><code>e1 = CircularQuantity(4090, 4096)\ne2 = CircularQuantity(10, 4096)\ndelta = e1.shortest_distance_to(e2)\n# Result: 20 counts</code></pre>\n        </div>\n    </div>\n</div>\n\n","title":"The General Pattern"},{"content":"<div class=\"slide\">\n    <h1>The Mathematical Insight</h1>\n    \n    <div class=\"info-box\">\n        <h3>Why Does This Work?</h3>\n        <div class=\"visual-demo\">\n            <svg width=\"600\" height=\"150\" viewBox=\"0 0 600 150\">\n                <!-- Line with endpoints -->\n                <g transform=\"translate(100, 75)\">\n                    <line x1=\"-60\" y1=\"0\" x2=\"60\" y2=\"0\" stroke=\"#333\" stroke-width=\"3\"/>\n                    <circle cx=\"-60\" cy=\"0\" r=\"6\" fill=\"#FF5722\"/>\n                    <circle cx=\"60\" cy=\"0\" r=\"6\" fill=\"#FF5722\"/>\n                    <text x=\"0\" y=\"30\" text-anchor=\"middle\" font-size=\"14\" fill=\"#FFC107\">Line has endpoints</text>\n                </g>\n                \n                <!-- vs -->\n                <text x=\"300\" y=\"80\" text-anchor=\"middle\" font-size=\"20\" fill=\"#FFC107\">vs</text>\n                \n                <!-- Circle -->\n                <g transform=\"translate(500, 40)\">\n                    <circle cx=\"0\" cy=\"0\" r=\"50\" fill=\"none\" stroke=\"#333\" stroke-width=\"3\"/>\n                    <text x=\"0\" y=\"70\" text-anchor=\"middle\" font-size=\"14\" fill=\"#FFC107\">Circle has none!</text>\n                </g>\n            </svg>\n        </div>\n        <p class=\"text-center\">A circle (S¹) is topologically different from a line segment. Linear math breaks at the wraparound point.</p>\n    </div>\n    \n    <div class=\"two-column-equal\">\n        <div class=\"card\">\n            <h3>🌐 The Circle Problem</h3>\n            <ul>\n                <li><strong>Circles have no \"beginning\" or \"end\"</strong></li>\n                <li>359° and 1° are neighbors</li>\n                <li>But arithmetic says 359 - 1 = 358 🤦</li>\n                <li>→ Solution: Use 2D vectors instead!</li>\n            </ul>\n        </div>\n        \n        <div class=\"card\">\n            <h3>🔄 The Wrapping Function</h3>\n            <svg width=\"300\" height=\"120\" viewBox=\"0 0 300 120\">\n                <path d=\"M 20 80 Q 70 20, 120 80 T 220 80 T 280 80\" stroke=\"#2196F3\" stroke-width=\"3\" fill=\"none\"/>\n                <text x=\"50\" y=\"60\" text-anchor=\"middle\" font-size=\"12\" fill=\"#FFC107\">0°</text>\n                <text x=\"120\" y=\"60\" text-anchor=\"middle\" font-size=\"12\" fill=\"#FFC107\">360°</text>\n                <text x=\"190\" y=\"60\" text-anchor=\"middle\" font-size=\"12\" fill=\"#FFC107\">720°</text>\n                <text x=\"260\" y=\"60\" text-anchor=\"middle\" font-size=\"12\" fill=\"#FFC107\">1080°</text>\n            </svg>\n            <p>Angles wrap around: 370° = 10°, 730° = 10°, etc. The infinite line wraps onto the finite circle.</p>\n        </div>\n    </div>\n    \n    <div class=\"success-box\">\n        <h3>🔑 The Universal Pattern</h3>\n        <div class=\"process-flow\">\n            <div class=\"process-step\">\n                <h4>Problem Space</h4>\n                <p>Non-linear manifold</p>\n                <small>(circle, sphere, torus)</small>\n            </div>\n            <div class=\"process-step\">\n                <h4>Embedding</h4>\n                <p>Lift to linear space</p>\n                <small>(ℝ², ℝ³, ℂ)</small>\n            </div>\n            <div class=\"process-step\">\n                <h4>Computation</h4>\n                <p>Do linear algebra</p>\n                <small>(add, average, interpolate)</small>\n            </div>\n            <div class=\"process-step\">\n                <h4>Projection</h4>\n                <p>Map back to manifold</p>\n                <small>(atan2, normalize)</small>\n            </div>\n        </div>\n    </div>\n    \n    <div class=\"two-column\">\n        <div class=\"warning-box\">\n            <h3>🎯 Where Else This Appears</h3>\n            <ul>\n                <li><strong>Quaternions:</strong> 3D rotations in 4D space</li>\n                <li><strong>Complex Numbers:</strong> 2D rotations in ℂ</li>\n                <li><strong>Fourier Transform:</strong> Signals on unit circle</li>\n                <li><strong>Neural Networks:</strong> Learned embeddings</li>\n            </ul>\n        </div>\n        \n        <div class=\"highlight-box\">\n            <h3>💭 Mathematical Insight</h3>\n            <blockquote style=\"font-style: italic; margin: 10px 0;\">\n                \"The introduction of numbers as coordinates is an act of violence.\"\n                <br><cite style=\"font-size: 14px;\">— Hermann Weyl</cite>\n            </blockquote>\n            <p><strong>But sometimes, the right coordinates make the violence worthwhile!</strong></p>\n        </div>\n    </div>\n</div>\n\n","title":"The Mathematical Insight"},{"content":"<div class=\"slide\">\n    <h1>Key Takeaways</h1>\n    \n    <div class=\"main-takeaway\">\n        <h2>🎯 The Golden Rule</h2>\n        <div class=\"golden-rule\">\n            <p>When you see a quantity that wraps around,</p>\n            <p><strong>ask: \"Can I embed this on a circle?\"</strong></p>\n        </div>\n    </div>\n    \n    <div class=\"practical-steps\">\n        <h3>Your Debugging Checklist</h3>\n        <div class=\"checklist\">\n            <div class=\"check-item\">\n                <span class=\"checkbox\">✓</span>\n                <div>\n                    <h4>Spot the Wraparound</h4>\n                    <p>Does your value jump discontinuously? (359° → 0°, 11:59 PM → 12:00 AM)</p>\n                </div>\n            </div>\n            \n            <div class=\"check-item\">\n                <span class=\"checkbox\">✓</span>\n                <div>\n                    <h4>Identify the Period</h4>\n                    <p>What's the cycle length? (360° for angles, 24 hours for time, 7 for weekdays)</p>\n                </div>\n            </div>\n            \n            <div class=\"check-item\">\n                <span class=\"checkbox\">✓</span>\n                <div>\n                    <h4>Choose Your Embedding</h4>\n                    <p>Usually: <code style=\"display: inline-block;\">(cos(<span style=\"display: inline-block; vertical-align: middle;\"><span style=\"display: block; text-align: center; border-bottom: 1px solid;\">2πx</span><span style=\"display: block; text-align: center;\">T</span></span>), sin(<span style=\"display: inline-block; vertical-align: middle;\"><span style=\"display: block; text-align: center; border-bottom: 1px solid;\">2πx</span><span style=\"display: block; text-align: center;\">T</span></span>))</code> where <code>T</code> is the period</p>\n                </div>\n            </div>\n            \n            <div class=\"check-item\">\n                <span class=\"checkbox\">✓</span>\n                <div>\n                    <h4>Work in Vector Space</h4>\n                    <p>Do all math on the vectors, not the raw values</p>\n                </div>\n            </div>\n            \n            <div class=\"check-item\">\n                <span class=\"checkbox\">✓</span>\n                <div>\n                    <h4>Project Back When Needed</h4>\n                    <p>Use <code>atan2(y, x)</code> to recover the original quantity</p>\n                </div>\n            </div>\n        </div>\n    </div>\n    \n    <div class=\"libraries-section\">\n        <h3>Don't Reinvent: Use Libraries!</h3>\n        <div class=\"library-grid\">\n            <div class=\"library\">\n                <h4>Python</h4>\n                <ul>\n                    <li><code>scipy.stats.circmean</code></li>\n                    <li><code>astropy.coordinates</code></li>\n                    <li><code>pyquaternion</code></li>\n                </ul>\n            </div>\n            \n            <div class=\"library\">\n                <h4>JavaScript</h4>\n                <ul>\n                    <li><code>d3-interpolate</code></li>\n                    <li><code>three.js Quaternion</code></li>\n                    <li><code>tinycolor2</code></li>\n                </ul>\n            </div>\n            \n            <div class=\"library\">\n                <h4>C++</h4>\n                <ul>\n                    <li><code>Eigen::AngleAxis</code></li>\n                    <li><code>boost::geometry</code></li>\n                    <li><code>tf2</code> (ROS)</li>\n                </ul>\n            </div>\n            \n            <div class=\"library\">\n                <h4>MATLAB</h4>\n                <ul>\n                    <li><code>circstat toolbox</code></li>\n                    <li><code>Aerospace Toolbox</code></li>\n                    <li><code>angle()</code>, <code>unwrap()</code></li>\n                </ul>\n            </div>\n        </div>\n    </div>\n    \n    <div class=\"red-flags\">\n        <h3>🚩 Red Flags in Your Code</h3>\n        <div class=\"flag-list\">\n            <div class=\"flag\">\n                <code>if (angle > 180) angle -= 360;</code>\n                <span>→ Use circular math instead</span>\n            </div>\n            <div class=\"flag\">\n                <code>if (crossed_midnight) /* special case */</code>\n                <span>→ Embed on 24-hour circle</span>\n            </div>\n            <div class=\"flag\">\n                <code>while (phase > π) phase -= 2π;</code>\n                <span>→ Work with complex exponentials</span>\n            </div>\n            <div class=\"flag\">\n                <code>// TODO: handle wraparound</code>\n                <span>→ Today's the day!</span>\n            </div>\n        </div>\n    </div>\n    \n    <div class=\"success-story\">\n        <div class=\"story-content\">\n            <h3>🎉 Success Story</h3>\n            <p>\"After this talk, I fixed a 3-year-old GPS bearing bug in 5 lines of code. The robot finally drives in straight lines!\"</p>\n            <cite>— Future You</cite>\n        </div>\n    </div>\n</div>\n\n","title":"Key Takeaways"},{"content":"<div class=\"slide\">\n    <h1>Interactive Demo</h1>\n    \n    <div class=\"demo-container\">\n        <div class=\"demo-section\">\n            <h3>🎮 Try It Yourself: Angle Averaging</h3>\n            \n            <div class=\"angle-inputs\">\n                <label>\n                    Angle 1: <input type=\"range\" id=\"angle1\" min=\"0\" max=\"359\" value=\"350\">\n                    <span id=\"angle1-display\">350°</span>\n                </label>\n                <label>\n                    Angle 2: <input type=\"range\" id=\"angle2\" min=\"0\" max=\"359\" value=\"10\">\n                    <span id=\"angle2-display\">10°</span>\n                </label>\n            </div>\n            \n            <div class=\"demo-visual\">\n                <svg width=\"400\" height=\"400\" viewBox=\"0 0 400 400\" id=\"demo-svg\">\n                    <!-- Circle -->\n                    <circle cx=\"200\" cy=\"200\" r=\"150\" fill=\"none\" stroke=\"#333\" stroke-width=\"2\"/>\n                    \n                    <!-- Compass labels -->\n                    <text x=\"200\" y=\"30\" text-anchor=\"middle\" font-size=\"16\" font-weight=\"bold\" fill=\"#FFC107\">0°</text>\n                    <text x=\"370\" y=\"205\" text-anchor=\"middle\" font-size=\"16\" font-weight=\"bold\" fill=\"#FFC107\">90°</text>\n                    <text x=\"200\" y=\"380\" text-anchor=\"middle\" font-size=\"16\" font-weight=\"bold\" fill=\"#FFC107\">180°</text>\n                    <text x=\"30\" y=\"205\" text-anchor=\"middle\" font-size=\"16\" font-weight=\"bold\" fill=\"#FFC107\">270°</text>\n                    \n                    <!-- Angle 1 line -->\n                    <line id=\"angle1-line\" x1=\"200\" y1=\"200\" x2=\"200\" y2=\"50\" stroke=\"#2196F3\" stroke-width=\"4\"/>\n                    <circle id=\"angle1-point\" cx=\"200\" cy=\"50\" r=\"8\" fill=\"#2196F3\"/>\n                    \n                    <!-- Angle 2 line -->\n                    <line id=\"angle2-line\" x1=\"200\" y1=\"200\" x2=\"200\" y2=\"50\" stroke=\"#4CAF50\" stroke-width=\"4\"/>\n                    <circle id=\"angle2-point\" cx=\"200\" cy=\"50\" r=\"8\" fill=\"#4CAF50\"/>\n                    \n                    <!-- Average (wrong) -->\n                    <line id=\"avg-wrong-line\" x1=\"200\" y1=\"200\" x2=\"200\" y2=\"350\" stroke=\"#FF5722\" stroke-width=\"3\" stroke-dasharray=\"5,5\" opacity=\"0\"/>\n                    <circle id=\"avg-wrong-point\" cx=\"200\" cy=\"350\" r=\"6\" fill=\"#FF5722\" opacity=\"0\"/>\n                    \n                    <!-- Average (correct) -->\n                    <line id=\"avg-correct-line\" x1=\"200\" y1=\"200\" x2=\"200\" y2=\"50\" stroke=\"#FFC107\" stroke-width=\"4\"/>\n                    <circle id=\"avg-correct-point\" cx=\"200\" cy=\"50\" r=\"8\" fill=\"#FFC107\"/>\n                </svg>\n            </div>\n            \n            <div class=\"demo-results\">\n                <div class=\"result wrong-result\">\n                    <h4>❌ Linear Average</h4>\n                    <p id=\"wrong-result\">180°</p>\n                </div>\n                \n                <div class=\"result correct-result\">\n                    <h4>✅ Circular Average</h4>\n                    <p id=\"correct-result\">0°</p>\n                </div>\n            </div>\n        </div>\n        \n        <div class=\"code-section\">\n            <h3>The Code Behind It</h3>\n            <pre><code id=\"demo-code\">function circularAverage(a1, a2) {\n    // Convert to radians\n    const theta1 = a1 * Math.PI / 180;\n    const theta2 = a2 * Math.PI / 180;\n    \n    // Embed on unit circle\n    const v1 = [Math.cos(theta1), Math.sin(theta1)];\n    const v2 = [Math.cos(theta2), Math.sin(theta2)];\n    \n    // Average vectors\n    const avgVec = [(v1[0] + v2[0])/2, (v1[1] + v2[1])/2];\n    \n    // Convert back to angle\n    const avgTheta = Math.atan2(avgVec[1], avgVec[0]);\n    return (avgTheta * 180 / Math.PI + 360) % 360;\n}</code></pre>\n        </div>\n    </div>\n</div>\n\n\n","title":"Interactive Demo"},{"content":"<div class=\"slide\" style=\"display:grid; gap:12px;\">\n  <h1>🌍 GIS Demo: Longitude Wraparound at the International Date Line</h1>\n  \n  <div class=\"info-box\">\n    <h3>Real-World Problem: Computing Geographic Means</h3>\n    <p>When averaging GPS coordinates near ±180° longitude (International Date Line), linear arithmetic fails spectacularly. A farm field split by the date line appears to span the entire globe!</p>\n  </div>\n  \n  <div id=\"map\" style=\"height:600px; border-radius:12px; overflow:hidden; border:1px solid rgba(255,255,255,.15)\"></div>\n  \n  <div style=\"display:flex; gap:16px; flex-wrap:wrap; align-items:center;\">\n    <label><input type=\"checkbox\" id=\"worldCopy\" checked> worldCopyJump (wrap world)</label>\n    <label><input type=\"checkbox\" id=\"noWrapTiles\"> tile noWrap (stop wrapping tiles)</label>\n    <span id=\"readout\" style=\"opacity:.9; font-family: monospace;\">Circular mean: …</span>\n  </div>\n  \n  <div class=\"success-box\">\n    <h3>🎯 Try This: Drag the markers across the International Date Line!</h3>\n    <p><strong>Red marker</strong> = Wrong linear mean | <strong>Green marker</strong> = Correct circular mean</p>\n    <p>Watch how the linear mean jumps to the middle of the Atlantic while the circular mean stays put! This is the classic longitude wraparound bug.</p>\n  </div>\n  \n  <div class=\"code-example\">\n    <h3>Spherical Coordinate Embedding</h3>\n    <pre><code class=\"language-python\"># For full lat/long geometry operations\ndef latlon_to_cartesian(lat, lon):\n    \"\"\"Embed (lat,lon) in R³ for linear operations\"\"\"\n    lat_rad = np.radians(lat)\n    lon_rad = np.radians(lon)\n    return np.array([\n        np.cos(lat_rad) * np.cos(lon_rad),  # x\n        np.cos(lat_rad) * np.sin(lon_rad),  # y  \n        np.sin(lat_rad)                     # z\n    ])\n\n# Geographic centroid (works across antimeridian!)\ndef geographic_centroid(lat_lon_pairs):\n    cartesian_points = [latlon_to_cartesian(lat, lon) \n                       for lat, lon in lat_lon_pairs]\n    mean_cartesian = np.mean(cartesian_points, axis=0)\n    mean_cartesian /= np.linalg.norm(mean_cartesian)  # Back to unit sphere\n    \n    # Convert back to lat/lon\n    lat = np.degrees(np.arcsin(mean_cartesian[2]))\n    lon = np.degrees(np.arctan2(mean_cartesian[1], mean_cartesian[0]))\n    return lat, lon</code></pre>\n  </div>\n  \n  <div class=\"warning-box\">\n    <h3>🏢 Company Applications</h3>\n    <ul>\n      <li><strong>Spatial Statistics:</strong> Computing true centroids for service areas</li>\n      <li><strong>Route Optimization:</strong> Distance calculations that work globally</li>\n      <li><strong>Geofencing:</strong> Boundary checks that don't break at meridians</li>\n      <li><strong>Data Quality:</strong> Detecting GPS outliers using proper spherical distance</li>\n    </ul>\n  </div>\n</div>\n\n","title":"🌍 GIS Demo: Longitude Wraparound at the International Date Line"},{"content":"<div class=\"slide flight-now\">\n  <style>\n    .flight-now {\n      padding: 3vh 4vw;\n      display: flex;\n      flex-direction: column;\n      gap: 2vh;\n    }\n\n    .flight-now h2 {\n      text-align: center;\n      margin-bottom: 1vh;\n      background: linear-gradient(135deg, #ff6b6b, #4ecdc4);\n      -webkit-background-clip: text;\n      background-clip: text;\n      color: transparent;\n    }\n\n    .grid {\n      display: grid;\n      grid-template-columns: 1fr 1.2fr;\n      gap: 3vw;\n      flex: 1;\n    }\n\n    .panel {\n      background: rgba(255, 255, 255, 0.03);\n      border-radius: 12px;\n      padding: 2vh 2vw;\n      border: 1px solid rgba(255, 255, 255, 0.1);\n    }\n\n    .left.panel {\n      display: flex;\n      flex-direction: column;\n      gap: 1.5vh;\n    }\n\n    .left.panel h3 {\n      margin: 0 0 1vh 0;\n      color: #4ecdc4;\n      font-size: 1.4em;\n    }\n\n    .row {\n      display: flex;\n      gap: 1vw;\n      align-items: center;\n    }\n\n    .row input, .row button, .row select {\n      padding: 8px 12px;\n      background: rgba(255, 255, 255, 0.1);\n      border: 1px solid rgba(255, 255, 255, 0.2);\n      border-radius: 6px;\n      color: #c9d1d9;\n      font-size: 14px;\n    }\n\n    .row input:focus, .row button:focus, .row select:focus {\n      outline: none;\n      border-color: #4ecdc4;\n      box-shadow: 0 0 0 2px rgba(78, 205, 196, 0.2);\n    }\n\n    .row button {\n      background: #4ecdc4;\n      color: #0d1117;\n      cursor: pointer;\n      font-weight: 600;\n    }\n\n    .row button:hover {\n      background: #3bb5a8;\n    }\n\n    label {\n      font-weight: 600;\n      color: #f0f6fc;\n      font-size: 0.9em;\n      margin-bottom: 0.5vh;\n      display: block;\n    }\n\n    .muted {\n      color: #7d8590;\n      font-size: 0.85em;\n    }\n\n    .notes {\n      padding: 1vh;\n      background: rgba(255, 255, 255, 0.02);\n      border-radius: 6px;\n      border-left: 3px solid #4ecdc4;\n    }\n\n    .g { color: #3fb950; }\n    .r { color: #f85149; }\n    .b { color: #58a6ff; }\n\n    .right.panel {\n      display: flex;\n      flex-direction: column;\n      gap: 1.5vh;\n    }\n\n    #utc-timeline {\n      background: rgba(255, 255, 255, 0.02);\n      border-radius: 8px;\n      border: 1px solid rgba(255, 255, 255, 0.1);\n    }\n\n    .outputs {\n      display: flex;\n      flex-direction: column;\n      gap: 1vh;\n    }\n\n    .chip {\n      padding: 0.8vh 1.2vw;\n      border-radius: 6px;\n      font-weight: 600;\n      font-size: 0.9em;\n      display: flex;\n      align-items: center;\n      gap: 0.5em;\n    }\n\n    .chip.g {\n      background: rgba(63, 185, 80, 0.15);\n      border: 1px solid rgba(63, 185, 80, 0.3);\n    }\n\n    .chip.r {\n      background: rgba(248, 81, 73, 0.15);\n      border: 1px solid rgba(248, 81, 73, 0.3);\n    }\n\n    .chip.b {\n      background: rgba(88, 166, 255, 0.15);\n      border: 1px solid rgba(88, 166, 255, 0.3);\n    }\n\n    .local-readouts {\n      padding: 1vh;\n      background: rgba(255, 255, 255, 0.02);\n      border-radius: 6px;\n      text-align: center;\n      font-size: 0.85em;\n    }\n\n    .dst-controls {\n      display: none;\n      background: rgba(255, 193, 7, 0.1);\n      border: 1px solid rgba(255, 193, 7, 0.3);\n      border-radius: 6px;\n      padding: 1vh;\n      font-size: 0.85em;\n    }\n\n    .dst-controls.show {\n      display: block;\n    }\n\n    .ring-explainer {\n      background: rgba(78, 205, 196, 0.1);\n      border: 1px solid rgba(78, 205, 196, 0.3);\n      border-radius: 8px;\n      padding: 1.5vh 1.5vw;\n      margin-top: 1vh;\n    }\n\n    .ring-explainer h4 {\n      margin: 0 0 1vh 0;\n      color: #4ecdc4;\n      font-size: 1em;\n    }\n\n    .ring-explainer ul {\n      margin: 0;\n      padding-left: 1.5em;\n      font-size: 0.9em;\n      line-height: 1.4;\n    }\n\n    .ring-explainer li {\n      margin-bottom: 0.3em;\n    }\n  </style>\n\n  <h2>Flight vs Now: Timezone Ring Embedding</h2>\n\n  <div class=\"grid\">\n    <div class=\"left panel\">\n      <h3>Times & Timezones</h3>\n\n      <label>Flight ended in Sydney (Australia/Sydney)</label>\n      <div class=\"row\">\n        <input id=\"syd-date\" type=\"date\" value=\"2025-09-15\">\n        <input id=\"syd-time\" type=\"time\" step=\"900\" value=\"08:10\">\n      </div>\n\n      <div id=\"dst-controls\" class=\"dst-controls\">\n        <div>⚠️ <strong>DST transition detected!</strong></div>\n        <div id=\"dst-message\"></div>\n      </div>\n\n      <label>Compare with San Francisco (America/Los_Angeles)</label>\n      <div class=\"row\">\n        <button id=\"sf-now\">Use Now</button>\n        <span id=\"sf-now-readout\" class=\"muted\">Click to set current time</span>\n      </div>\n\n      <div class=\"row\" style=\"margin-top: 1vh;\">\n        <button id=\"dst-demo\" style=\"background: #ff9500; font-size: 0.85em;\">DST Demo (Oct 5)</button>\n        <span class=\"muted\" style=\"font-size: 0.8em;\">Shows spring-forward gap</span>\n      </div>\n\n      <div class=\"notes\">\n        Both deltas shown: <span class=\"g\">correct (UTC instants)</span> & <span class=\"r\">naive (local wall times)</span>.\n        The naive approach fails because it ignores timezone offsets and DST transitions.\n      </div>\n\n      <div class=\"ring-explainer\">\n        <h4>🔄 Ring Embedding Approach</h4>\n        <ul>\n          <li><strong>Instants:</strong> Linear UTC timeline → safe arithmetic</li>\n          <li><strong>Local times:</strong> 24h circular ring → avoid midnight jumps</li>\n          <li><strong>Naive error:</strong> Treats different timezone \"rings\" as same coordinates</li>\n        </ul>\n      </div>\n    </div>\n\n    <div class=\"right panel\">\n      <svg id=\"utc-timeline\" viewBox=\"0 0 900 160\" aria-label=\"UTC timeline\">\n        <!-- Timeline will be drawn by JavaScript -->\n      </svg>\n\n      <div class=\"outputs\">\n        <div class=\"chip g\">Δt (correct): <span id=\"dt-correct\">Calculate times first</span></div>\n        <div class=\"chip r\">Δt (naive): <span id=\"dt-naive\">Calculate times first</span> <span class=\"muted\">(misleading)</span></div>\n        <div class=\"chip b\">Offset difference: <span id=\"offset-diff\">—</span></div>\n      </div>\n\n      <div class=\"local-readouts muted\">\n        <div><strong>Local readouts:</strong></div>\n        <div id=\"syd-readout\">Sydney: Set date/time above</div>\n        <div id=\"sf-readout\">San Francisco: Click \"Use Now\"</div>\n      </div>\n    </div>\n  </div>\n</div>","title":"Untitled Slide"},{"content":"<div class=\"slide\">\n    <div class=\"questions-slide\">\n        <h1>Questions?</h1>\n        \n        <div class=\"contact-info\">\n            <div class=\"demo-offer\">\n                <h3>🔬 Want to See This in Action?</h3>\n                <p>I've got interactive demos for:</p>\n                <ul>\n                    <li>Live angle averaging visualization</li>\n                    <li>Color interpolation comparison</li>\n                    <li>Robot heading controller simulation</li>\n                </ul>\n            </div>\n            \n            <div class=\"resources\">\n                <h3>📚 Resources</h3>\n                <ul>\n                    <li><strong>Slides:</strong> Available on internal wiki</li>\n                    <li><strong>Code Examples:</strong> Python/JS implementations</li>\n                    <li><strong>Further Reading:</strong> \"Lie Groups for Computer Vision\" by Ethan Eade</li>\n                </ul>\n            </div>\n        </div>\n        \n        <div class=\"challenge\">\n            <h3>🏆 Challenge for Next Week</h3>\n            <div class=\"challenge-box\">\n                <p>Find ONE wraparound bug in your current codebase</p>\n                <p>Try the embedding approach</p>\n                <p>Share your results!</p>\n            </div>\n        </div>\n        \n        <div class=\"final-thought\">\n            <blockquote>\n                \"The best way to learn mathematics is to do mathematics.\"\n                <cite>— Paul Halmos</cite>\n            </blockquote>\n            <p>So go break some rings! 💍➡️📐</p>\n        </div>\n        \n        <div class=\"thank-you\">\n            <h2>Thank You!</h2>\n            <div class=\"outro-visual\">\n                <svg width=\"300\" height=\"150\" viewBox=\"0 0 300 150\">\n                    <!-- Circle with happy face -->\n                    <circle cx=\"150\" cy=\"75\" r=\"60\" fill=\"none\" stroke=\"#4CAF50\" stroke-width=\"3\"/>\n                    \n                    <!-- Happy eyes -->\n                    <circle cx=\"130\" cy=\"60\" r=\"5\" fill=\"#4CAF50\"/>\n                    <circle cx=\"170\" cy=\"60\" r=\"5\" fill=\"#4CAF50\"/>\n                    \n                    <!-- Happy smile -->\n                    <path d=\"M 120 90 Q 150 110 180 90\" fill=\"none\" stroke=\"#4CAF50\" stroke-width=\"3\"/>\n                    \n                    <!-- Surrounding points showing smooth embedding -->\n                    <g opacity=\"0.5\">\n                        <circle cx=\"90\" cy=\"75\" r=\"3\" fill=\"#2196F3\"/>\n                        <circle cx=\"210\" cy=\"75\" r=\"3\" fill=\"#2196F3\"/>\n                        <circle cx=\"150\" cy=\"15\" r=\"3\" fill=\"#2196F3\"/>\n                        <circle cx=\"150\" cy=\"135\" r=\"3\" fill=\"#2196F3\"/>\n                        \n                        <!-- Smooth curves connecting them -->\n                        <path d=\"M 90 75 Q 90 15, 150 15\" fill=\"none\" stroke=\"#2196F3\" stroke-width=\"1\" opacity=\"0.3\"/>\n                        <path d=\"M 150 15 Q 210 15, 210 75\" fill=\"none\" stroke=\"#2196F3\" stroke-width=\"1\" opacity=\"0.3\"/>\n                        <path d=\"M 210 75 Q 210 135, 150 135\" fill=\"none\" stroke=\"#2196F3\" stroke-width=\"1\" opacity=\"0.3\"/>\n                        <path d=\"M 150 135 Q 90 135, 90 75\" fill=\"none\" stroke=\"#2196F3\" stroke-width=\"1\" opacity=\"0.3\"/>\n                    </g>\n                    \n                    <text x=\"150\" y=\"160\" text-anchor=\"middle\" font-size=\"12\" fill=\"#666\">\n                        No more wraparound headaches!\n                    </text>\n                </svg>\n            </div>\n        </div>\n    </div>\n</div>\n\n","title":"Questions?"}];

// Slide configuration - add slide filenames here in order
const slideFiles = [
    'slides/01-title.html',
    'slides/02-the-bug.html',
    'slides/03-midnight-bug.html',
    'slides/04-the-solution.html',
    'slides/13-circular-statistics.html',
    'slides/14-discrete-calculus.html',
    'slides/15-other-circular-quantities.html',
    'slides/16-arbitrary-wrap-points.html',
    'slides/05-robot-heading.html',
    'slides/06-color-interpolation.html',
    'slides/07-general-pattern.html',
    'slides/08-mathematical-insight.html',
    'slides/09-takeaways.html',
    'slides/11-interactive-demo.html',
    'slides/12-gis-demo.html',
    'slides/16-vector-calculator.html',
    'slides/17-timeseries-analyzer.html',
    'slides/18-flight-vs-now.html',
    'slides/10-questions.html'
];

let currentSlide = 0;
let slidesLoaded = false;

// Global interactive app manager
window.currentInteractiveApp = null;

// Get total number of slides (from embedded data or file list)
const totalSlides = window.slideData ? Object.keys(window.slideData).length : slideFiles.length;

// Load slide content (either from embedded data or fetch)
async function loadSlide(index) {
    if (index < 0 || index >= totalSlides) return;

    console.log(`${'='.repeat(80)}`);
    console.log(`🎬 LOADING SLIDE ${index + 1}/${totalSlides}: ${slideFiles[index]?.split('/').pop() || `slide-${index}`}`);
    console.log(`   Full path: ${slideFiles[index] || `slide-${index}`}`);
    console.log(`${'='.repeat(80)}`);
    
    // Clean up any existing interactive app
    if (window.currentInteractiveApp) {
        window.currentInteractiveApp.destroy(true, { children: true, texture: true, baseTexture: true });
        window.currentInteractiveApp = null;
    }
    
    try {
        let content;
        
        // Check if we have embedded slide data (bundled version)
        if (window.slideData) {
            content = window.slideData[index.toString()];
            if (!content) {
                throw new Error(`Slide data not found for key: ${index}`);
            }
        } else {
            // Fetch individual slide files (bundle folder version)
            const response = await fetch(slideFiles[index]);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            content = await response.text();
        }
        
        document.getElementById('slide-content').innerHTML = content;
        
        // Ensure code blocks have proper language classes and highlight syntax
        const slideContent = document.getElementById('slide-content');
        
        // Fix code classes for Highlight.js compatibility
        slideContent.querySelectorAll('pre code').forEach(el => {
            const cls = el.getAttribute('class') || '';
            if (/\bpython\b/i.test(cls) && !/\blanguage-python\b/i.test(cls)) {
                el.className = (cls + ' language-python').trim();
            }
            if (/\bjavascript\b/i.test(cls) && !/\blanguage-javascript\b/i.test(cls)) {
                el.className = (cls + ' language-javascript').trim();
            }
        });

        // Initialize demos based on slide content
        console.log('🔍 Checking slide for interactive elements...');
        
        // Check if this is the interactive demo slide (look for the svg element)
        if (slideContent.querySelector('#demo-svg')) {
            console.log('🎮 Interactive Demo slide detected, initializing...');
            console.log('initInteractiveDemo function exists:', typeof initInteractiveDemo);
            setTimeout(initInteractiveDemo, 100);
        }
        
        // Check if this is the GIS demo slide (look for the map container)
        if (slideContent.querySelector('#map')) {
            console.log('🗺️  GIS Demo slide detected, initializing...');
            console.log('initGISDemo function exists:', typeof initGISDemo);
            setTimeout(initGISDemo, 100);
        }
        
        // Check if this is the Vector Calculator slide
        if (slideContent.querySelector('#vector-calculator-container')) {
            console.log('🧮 Vector Calculator slide detected, initializing...');
            console.log('initVectorCalculator function exists:', typeof initVectorCalculator);
            setTimeout(initVectorCalculator, 100);
        }
        
        // Check if this is the Time Series Analyzer slide
        if (slideContent.querySelector('#timeseries-analyzer-container')) {
            console.log('📈 Time Series Analyzer slide detected, initializing...');
            console.log('initTimeSeriesAnalyzer function exists:', typeof initTimeSeriesAnalyzer);
            setTimeout(initTimeSeriesAnalyzer, 100);
        }

        // Check if this is the Flight vs Now timezone slide
        if (slideContent.querySelector('#utc-timeline')) {
            console.log('🕓 Flight vs Now slide detected, initializing...');
            console.log('initFlightVsNow exists:', typeof initFlightVsNow);
            setTimeout(initFlightVsNow, 100);
        }

        // Check if this is the color interpolation hue wheel slide
        if (slideContent.querySelector('#dwSVG')) {
            console.log('🎨 Color interpolation slide detected, initializing...');
            console.log('initHueDragWheel exists:', typeof initHueDragWheel);
            setTimeout(initHueDragWheel, 100);
        }

        // Re-run Highlight.js on the new content
        if (window.hljs) {
            slideContent.querySelectorAll('pre code').forEach(block => {
                hljs.highlightElement(block);
            });
        }
        
        // Add fade in animation
        slideContent.style.animation = 'none';
        slideContent.offsetHeight; // Trigger reflow
        slideContent.style.animation = 'fadeIn 0.5s';

        // Dispatch custom event for SVG layout fixing
        window.dispatchEvent(new CustomEvent('slideLoaded'));

    } catch (error) {
        console.error('Error loading slide:', error);
        document.getElementById('slide-content').innerHTML = `
            <h1>Error Loading Slide</h1>
            <p>Could not load slide: ${slideFiles[index]}</p>
            <p>Error: ${error.message}</p>
        `;
    }
}

function updateNavigation() {
    const prevButton = document.querySelector('.nav-button');
    const nextButton = document.querySelector('.nav-button:last-child');
    
    // Never disable buttons since we wrap around
    prevButton.disabled = false;
    nextButton.disabled = false;
    
    document.getElementById('current-slide').textContent = currentSlide + 1;
    document.getElementById('total-slides').textContent = totalSlides;
}

function nextSlide() {
    console.log(`🔄 nextSlide() called - currentSlide: ${currentSlide}, totalSlides: ${totalSlides}`);
    if (currentSlide < totalSlides - 1) {
        currentSlide++;
    } else {
        currentSlide = 0; // Wrap to first slide
    }
    console.log(`🔄 About to call loadSlide(${currentSlide})`);
    loadSlide(currentSlide);
    updateNavigation();
}

function previousSlide() {
    console.log(`🔄 previousSlide() called - currentSlide: ${currentSlide}, totalSlides: ${totalSlides}`);
    if (currentSlide > 0) {
        currentSlide--;
    } else {
        currentSlide = totalSlides - 1; // Wrap to last slide
    }
    console.log(`🔄 About to call loadSlide(${currentSlide})`);
    loadSlide(currentSlide);
    updateNavigation();
}

// Jump to specific slide (for development/testing)
function goToSlide(index) {
    if (index >= 0 && index < totalSlides) {
        currentSlide = index;
        loadSlide(currentSlide);
        updateNavigation();
    }
}

// Keyboard navigation
document.addEventListener('keydown', function(event) {
    if (event.key === 'ArrowRight' || event.key === ' ') {
        event.preventDefault();
        nextSlide();
    } else if (event.key === 'ArrowLeft') {
        event.preventDefault();
        previousSlide();
    } else if (event.key >= '1' && event.key <= '9') {
        // Jump to slide by number key
        const slideNum = parseInt(event.key) - 1;
        if (slideNum < totalSlides) {
            goToSlide(slideNum);
        }
    } else if (event.key === 'Home') {
        goToSlide(0);
    } else if (event.key === 'End') {
        goToSlide(totalSlides - 1);
    }
});

// Wait for libraries and initialize presentation
function waitForLibrariesAndInit() {
    let attempts = 0;
    const maxAttempts = 50; // 5 seconds max

    const checkLibraries = setInterval(() => {
        attempts++;

        // Check if D3 and fc are loaded
        if (typeof window.d3 !== 'undefined' && typeof window.fc !== 'undefined') {
            clearInterval(checkLibraries);
            console.log('✅ D3 and fc libraries loaded successfully');
            console.log('   D3 version:', d3.version);
            console.log('   fc.layoutLabel available:', typeof fc.layoutLabel === 'function');

            // Initialize presentation
            console.log(`🚀 Initializing presentation - calling loadSlide(0)`);
            loadSlide(0);
            updateNavigation();
            slidesLoaded = true;

            // Add some helpful keyboard shortcuts info
            console.log('Keyboard shortcuts:');
            console.log('→ or Space: Next slide');
            console.log('←: Previous slide');
            console.log('1-9: Jump to slide');
            console.log('Home: First slide');
            console.log('End: Last slide');
        } else if (attempts >= maxAttempts) {
            clearInterval(checkLibraries);
            console.warn('⚠️ D3/fc libraries failed to load after', attempts, 'attempts');
            console.warn('   Continuing without SVG layout fixing...');

            // Initialize presentation anyway
            loadSlide(0);
            updateNavigation();
            slidesLoaded = true;
        } else if (attempts % 10 === 0) {
            console.log('⏳ Waiting for D3/fc libraries... attempt', attempts);
        }
    }, 100);
}

// Initialize presentation
document.addEventListener('DOMContentLoaded', waitForLibrariesAndInit);

// Interactive demo functionality for slide 10
function initInteractiveDemo() {
    const angle1Input = document.getElementById('angle1');
    const angle2Input = document.getElementById('angle2');
    const angle1Display = document.getElementById('angle1-display');
    const angle2Display = document.getElementById('angle2-display');
    const wrongResult = document.getElementById('wrong-result');
    const correctResult = document.getElementById('correct-result');
    
    // Check if elements exist (safety check)
    if (!angle1Input || !angle2Input) {
        console.log('Interactive demo elements not found');
        return;
    }
    
    function updateDemo() {
        const a1 = parseInt(angle1Input.value);
        const a2 = parseInt(angle2Input.value);
        
        // Update displays
        angle1Display.textContent = a1 + '°';
        angle2Display.textContent = a2 + '°';
        
        // Calculate wrong (linear) average
        const wrongAvg = (a1 + a2) / 2;
        wrongResult.textContent = Math.round(wrongAvg) + '°';
        
        // Calculate correct (circular) average
        const theta1 = a1 * Math.PI / 180;
        const theta2 = a2 * Math.PI / 180;
        const v1 = [Math.cos(theta1), Math.sin(theta1)];
        const v2 = [Math.cos(theta2), Math.sin(theta2)];
        const avgVec = [(v1[0] + v2[0])/2, (v1[1] + v2[1])/2];
        const norm = Math.sqrt(avgVec[0]**2 + avgVec[1]**2);
        avgVec[0] /= norm; avgVec[1] /= norm;
        const correctAvg = Math.atan2(avgVec[1], avgVec[0]) * 180 / Math.PI;
        const correctAvgNormalized = (correctAvg + 360) % 360;
        correctResult.textContent = Math.round(correctAvgNormalized) + '°';
        
        // Update visual
        updateVisual(a1, a2, wrongAvg, correctAvgNormalized);
        
        // Show/hide wrong result based on how wrong it is
        const wrongness = Math.abs(wrongAvg - correctAvgNormalized);
        const adjustedWrongness = Math.min(wrongness, 360 - wrongness);
        const opacity = adjustedWrongness > 30 ? 1 : 0;
        
        const wrongLine = document.getElementById('avg-wrong-line');
        const wrongPoint = document.getElementById('avg-wrong-point');
        if (wrongLine) wrongLine.style.opacity = opacity;
        if (wrongPoint) wrongPoint.style.opacity = opacity;
    }
    
    function updateVisual(a1, a2, wrongAvg, correctAvg) {
        const cx = 200, cy = 200, r = 150;
        
        // Convert angles to positions
        function angleToPos(angle) {
            const rad = (angle - 90) * Math.PI / 180; // -90 to start from top
            return {
                x: cx + r * Math.cos(rad),
                y: cy + r * Math.sin(rad)
            };
        }
        
        const pos1 = angleToPos(a1);
        const pos2 = angleToPos(a2);
        const wrongPos = angleToPos(wrongAvg);
        const correctPos = angleToPos(correctAvg);
        
        // Update lines and points safely
        const elements = [
            { id: 'angle1-line', x2: pos1.x, y2: pos1.y },
            { id: 'angle1-point', cx: pos1.x, cy: pos1.y },
            { id: 'angle2-line', x2: pos2.x, y2: pos2.y },
            { id: 'angle2-point', cx: pos2.x, cy: pos2.y },
            { id: 'avg-wrong-line', x2: wrongPos.x, y2: wrongPos.y },
            { id: 'avg-wrong-point', cx: wrongPos.x, cy: wrongPos.y },
            { id: 'avg-correct-line', x2: correctPos.x, y2: correctPos.y },
            { id: 'avg-correct-point', cx: correctPos.x, cy: correctPos.y }
        ];
        
        elements.forEach(elem => {
            const element = document.getElementById(elem.id);
            if (element) {
                if (elem.x2 !== undefined) element.setAttribute('x2', elem.x2);
                if (elem.y2 !== undefined) element.setAttribute('y2', elem.y2);
                if (elem.cx !== undefined) element.setAttribute('cx', elem.cx);
                if (elem.cy !== undefined) element.setAttribute('cy', elem.cy);
            }
        });
    }
    
    // Set up event listeners
    angle1Input.addEventListener('input', updateDemo);
    angle2Input.addEventListener('input', updateDemo);
    
    // Initial update
    updateDemo();
    
    console.log('Interactive demo initialized');
}

// GIS Demo functionality for slide 12
function initGISDemo() {
    // Check if Leaflet is loaded
    if (typeof L === 'undefined') {
        console.log('Leaflet not loaded yet, retrying...');
        setTimeout(initGISDemo, 200);
        return;
    }
    
    // Check if map container exists
    const mapContainer = document.getElementById('map');
    if (!mapContainer) {
        console.log('Map container not found');
        return;
    }
    
    // Clear any existing map
    if (window.gisMap) {
        window.gisMap.remove();
        window.gisMap = null;
    }
    
    try {
        // International Date Line area (where the real wraparound happens)
        const DATELINE_CENTER = [0.0, 180.0]; // Equator at 180° longitude

        // Map with world copy jump disabled initially, centered on the International Date Line
        const map = L.map('map', { 
            center: DATELINE_CENTER, 
            zoom: 4, 
            worldCopyJump: false 
        });
        window.gisMap = map; // Store reference for cleanup

        // OSM tiles with attribution
        let tiles = L.tileLayer(
            'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
            { 
                maxZoom: 19, 
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' 
            }
        ).addTo(map);
        window.gisTiles = tiles;

        // Two draggable points that straddle the International Date Line (the REAL wraparound!)
        const blueIcon = L.divIcon({
            className: 'custom-marker',
            html: '<div style="background:#2196F3; width:20px; height:20px; border-radius:50%; border:3px solid white; box-shadow:0 2px 6px rgba(0,0,0,0.3);"></div>',
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        });
        const orangeIcon = L.divIcon({
            className: 'custom-marker', 
            html: '<div style="background:#FF9800; width:20px; height:20px; border-radius:50%; border:3px solid white; box-shadow:0 2px 6px rgba(0,0,0,0.3);"></div>',
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        });
        
        const marker1 = L.marker([5.0, 175.0], {draggable:true, icon: blueIcon}).addTo(map).bindTooltip('+175°E', {permanent:true, direction:'right'});
        const marker2 = L.marker([15.0, 178.0], {draggable:true, icon: orangeIcon}).addTo(map).bindTooltip('+178°E', {permanent:true, direction:'left'});
        const pts = [marker1, marker2];
        window.gisMarkers = pts;
        
        console.log('Created GIS markers:', pts.length, 'markers at positions:', 
                   pts.map(m => `${m.getLatLng().lat},${m.getLatLng().lng}`));

        // Circular mean helper function
        function meanLonDeg(ds) {
            let x = 0, y = 0;
            for (const d of ds) {
                const r = d * Math.PI / 180;
                x += Math.cos(r); 
                y += Math.sin(r);
            }
            let m = Math.atan2(y, x) * 180 / Math.PI;
            if (m >= 180) m -= 360;
            if (m < -180) m += 360;
            return m;
        }

        // Result markers - RED for wrong, GREEN for correct
        const wrongMarker = L.circleMarker(DATELINE_CENTER, {
            radius: 12, 
            color: '#FF1744', 
            fillColor: '#FF5252', 
            fillOpacity: 0.9,
            weight: 3
        }).addTo(map).bindTooltip('WRONG: Linear Mean', {permanent: false, direction: 'top'});
        
        const correctMarker = L.circleMarker(DATELINE_CENTER, {
            radius: 15, 
            color: '#00C853', 
            fillColor: '#00E676', 
            fillOpacity: 0.9,
            weight: 3
        }).addTo(map).bindTooltip('CORRECT: Circular Mean', {permanent: false, direction: 'bottom'});
        const readout = document.getElementById('readout');
        
        window.gisResultMarkers = [wrongMarker, correctMarker];

        function update() {
            const lats = pts.map(m => m.getLatLng().lat);
            const lons = pts.map(m => m.getLatLng().lng);
            const latAvg = lats.reduce((a, b) => a + b, 0) / lats.length;
            const linMean = (lons[0] + lons[1]) / 2; // WRONG near 0°
            const circMean = meanLonDeg(lons);

            wrongMarker.setLatLng([latAvg, linMean]);
            correctMarker.setLatLng([latAvg, circMean]);

            // Tiny line showing crossing at 0° 
            if (window.crossLine) map.removeLayer(window.crossLine);
            window.crossLine = L.polyline([[latAvg, -0.01], [latAvg, 0.01]], {color:'#4FC3F7', weight:3}).addTo(map);

            if (readout) {
                readout.textContent = 
                    `Circular mean: ${circMean.toFixed(3)}°, Linear mean (wrong): ${((linMean + 540) % 360 - 180).toFixed(3)}°`;
            }
        }

        pts.forEach(m => m.on('drag dragend', update));
        update();

        // UI toggles
        const worldCopyCheckbox = document.getElementById('worldCopy');
        const noWrapTilesCheckbox = document.getElementById('noWrapTiles');
        
        if (worldCopyCheckbox) {
            worldCopyCheckbox.addEventListener('change', (e) => {
                map.options.worldCopyJump = !!e.target.checked;
                map.panBy([1, 0]); // nudge to apply visually
            });
        }
        
        if (noWrapTilesCheckbox) {
            noWrapTilesCheckbox.addEventListener('change', (e) => {
                const noWrap = !!e.target.checked;
                map.removeLayer(tiles);
                tiles = L.tileLayer(
                    'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                    { 
                        maxZoom: 19, 
                        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors', 
                        noWrap 
                    }
                ).addTo(map);
                window.gisTiles = tiles;
            });
        }

        console.log('GIS demo initialized');
    } catch (error) {
        console.error('Error initializing GIS demo:', error);
    }
}

// Flight vs Now timezone demonstration
function initFlightVsNow() {
    try {
        console.log('Initializing Flight vs Now timezone demo...');

        // Get DOM elements
        const sydDate = document.getElementById('syd-date');
        const sydTime = document.getElementById('syd-time');
        const sfNowBtn = document.getElementById('sf-now');
        const sfNowReadout = document.getElementById('sf-now-readout');
        const dstDemoBtn = document.getElementById('dst-demo');
        const utcTimeline = document.getElementById('utc-timeline');
        const dtCorrect = document.getElementById('dt-correct');
        const dtNaive = document.getElementById('dt-naive');
        const offsetDiff = document.getElementById('offset-diff');
        const sydReadout = document.getElementById('syd-readout');
        const sfReadout = document.getElementById('sf-readout');
        const dstControls = document.getElementById('dst-controls');
        const dstMessage = document.getElementById('dst-message');

        if (!sydDate || !sydTime || !sfNowBtn) {
            console.error('Required DOM elements not found');
            return;
        }

        let sfNowInstant = null; // UTC instant for SF "now"
        let sydFlightInstant = null; // UTC instant for Sydney flight

        // Helper to get timezone offset in hours for a specific instant and timezone
        function getTimezoneOffsetHours(epochMs, timeZone) {
            const date = new Date(epochMs);
            // Format in the target timezone to extract the offset
            const formatter = new Intl.DateTimeFormat('en-US', {
                timeZone,
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                timeZoneName: 'longOffset'
            });

            const formatted = formatter.format(date);
            // Extract offset from format like "GMT+10:00" or "GMT-07:00"
            const offsetMatch = formatted.match(/GMT([+-]\d{1,2}):?(\d{2})?/);
            if (offsetMatch) {
                const hours = parseInt(offsetMatch[1]);
                const minutes = offsetMatch[2] ? parseInt(offsetMatch[2]) : 0;
                return hours + (hours < 0 ? -minutes/60 : minutes/60);
            }
            return 0;
        }

        // Convert local Sydney date/time to UTC instant
        function localSydneyToInstant(dateStr, timeStr) {
            const [year, month, day] = dateStr.split('-').map(Number);
            const [hour, minute] = timeStr.split(':').map(Number);

            // Search window: day before to day after in UTC
            const searchStart = Date.UTC(year, month - 1, day - 1, 0, 0);
            const searchEnd = Date.UTC(year, month - 1, day + 2, 0, 0);
            const matches = [];

            // Search in 15-minute increments
            for (let utc = searchStart; utc <= searchEnd; utc += 15 * 60 * 1000) {
                const formatter = new Intl.DateTimeFormat('en-AU', {
                    timeZone: 'Australia/Sydney',
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: false
                });

                const parts = formatter.formatToParts(new Date(utc));
                const formatted = {};
                parts.forEach(p => formatted[p.type] = p.value);

                const formattedDate = `${formatted.year}-${formatted.month}-${formatted.day}`;
                const formattedTime = `${formatted.hour}:${formatted.minute}`;

                if (formattedDate === dateStr && formattedTime === timeStr) {
                    matches.push(utc);
                }
            }

            if (matches.length === 0) {
                // Spring-forward gap - find next valid time
                for (let utc = searchStart; utc <= searchEnd; utc += 15 * 60 * 1000) {
                    const formatter = new Intl.DateTimeFormat('en-AU', {
                        timeZone: 'Australia/Sydney',
                        year: 'numeric',
                        month: '2-digit',
                        day: '2-digit',
                        hour: '2-digit',
                        minute: '2-digit',
                        hour12: false
                    });

                    const parts = formatter.formatToParts(new Date(utc));
                    const formatted = {};
                    parts.forEach(p => formatted[p.type] = p.value);

                    const formattedDate = `${formatted.year}-${formatted.month}-${formatted.day}`;
                    const formattedTime = `${formatted.hour}:${formatted.minute}`;

                    if (formattedDate === dateStr && formattedTime > timeStr) {
                        return {
                            instant: utc,
                            status: 'gap',
                            adjustedTime: formattedTime
                        };
                    }
                }
                return { instant: null, status: 'gap' };
            } else if (matches.length === 1) {
                return { instant: matches[0], status: 'valid' };
            } else {
                // Fall-back: multiple matches, use earlier
                return { instant: matches[0], status: 'fold' };
            }
        }

        // Format duration nicely
        function formatDuration(milliseconds) {
            const totalMinutes = Math.round(milliseconds / (1000 * 60));
            const absMinutes = Math.abs(totalMinutes);
            const hours = Math.floor(absMinutes / 60);
            const minutes = absMinutes % 60;
            const sign = totalMinutes >= 0 ? '+' : '-';

            if (hours === 0) {
                return `${sign}${minutes}m`;
            } else if (minutes === 0) {
                return `${sign}${hours}h`;
            } else {
                return `${sign}${hours}h ${minutes}m`;
            }
        }

        // Format local time with timezone info
        function formatLocalTime(epochMs, timeZone) {
            if (!epochMs) return 'Invalid';

            const date = new Date(epochMs);
            const formatter = new Intl.DateTimeFormat('en-US', {
                timeZone,
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                timeZoneName: 'short'
            });

            const formatted = formatter.format(date);
            const offset = getTimezoneOffsetHours(epochMs, timeZone);
            const offsetStr = offset >= 0 ? `+${offset}` : `${offset}`;

            return `${formatted}, UTC${offsetStr}`;
        }

        // Calculate naive delta (local wall-clock subtraction)
        function calculateNaiveDelta(sydDateStr, sydTimeStr, sfEpochMs) {
            // Get SF local date/time
            const sfDate = new Date(sfEpochMs);
            const sfFormatter = new Intl.DateTimeFormat('en-US', {
                timeZone: 'America/Los_Angeles',
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                hour12: false
            });

            const sfParts = sfFormatter.formatToParts(sfDate);
            const sfFormatted = {};
            sfParts.forEach(p => sfFormatted[p.type] = p.value);

            // Parse both as if they were in the same timezone (ignoring offsets)
            const sydLocal = new Date(`${sydDateStr}T${sydTimeStr}:00`);
            const sfLocal = new Date(`${sfFormatted.year}-${sfFormatted.month}-${sfFormatted.day}T${sfFormatted.hour}:${sfFormatted.minute}:00`);

            return sfLocal.getTime() - sydLocal.getTime();
        }

        // Draw the UTC timeline
        function drawTimeline(sydInstant, sfInstant) {
            if (!utcTimeline || !sydInstant || !sfInstant) return;

            // Clear existing content
            utcTimeline.innerHTML = '';

            // Set explicit viewBox
            utcTimeline.setAttribute('viewBox', '0 0 900 160');

            // Timeline parameters
            const width = 900;
            const height = 160;
            const margin = { left: 50, right: 50, top: 30, bottom: 50 };
            const timelineY = height / 2;

            // Calculate time range
            const minTime = Math.min(sydInstant, sfInstant);
            const maxTime = Math.max(sydInstant, sfInstant);
            const padding = Math.max(3 * 60 * 60 * 1000, (maxTime - minTime) * 0.2); // At least 3 hours padding
            const startTime = minTime - padding;
            const endTime = maxTime + padding;

            // Scale function
            function timeToX(timestamp) {
                return margin.left + ((timestamp - startTime) / (endTime - startTime)) * (width - margin.left - margin.right);
            }

            // Draw main timeline
            const timeline = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            timeline.setAttribute('x1', margin.left);
            timeline.setAttribute('x2', width - margin.right);
            timeline.setAttribute('y1', timelineY);
            timeline.setAttribute('y2', timelineY);
            timeline.setAttribute('stroke', '#7d8590');
            timeline.setAttribute('stroke-width', '2');
            utcTimeline.appendChild(timeline);

            // Draw time markers
            const timeSpan = endTime - startTime;
            const hourMs = 60 * 60 * 1000;
            let markerInterval;

            if (timeSpan < 12 * hourMs) {
                markerInterval = hourMs; // Every hour for short spans
            } else if (timeSpan < 48 * hourMs) {
                markerInterval = 4 * hourMs; // Every 4 hours
            } else {
                markerInterval = 12 * hourMs; // Every 12 hours for long spans
            }

            const firstMarker = Math.ceil(startTime / markerInterval) * markerInterval;
            for (let t = firstMarker; t <= endTime; t += markerInterval) {
                const x = timeToX(t);

                // Tick mark
                const tick = document.createElementNS('http://www.w3.org/2000/svg', 'line');
                tick.setAttribute('x1', x);
                tick.setAttribute('x2', x);
                tick.setAttribute('y1', timelineY - 5);
                tick.setAttribute('y2', timelineY + 5);
                tick.setAttribute('stroke', '#7d8590');
                tick.setAttribute('stroke-width', '1');
                utcTimeline.appendChild(tick);

                // Time label
                const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                label.setAttribute('x', x);
                label.setAttribute('y', timelineY + 25);
                label.setAttribute('text-anchor', 'middle');
                label.setAttribute('fill', '#7d8590');
                label.setAttribute('font-size', '10');
                const date = new Date(t);
                label.textContent = date.toISOString().substring(11, 16) + ' UTC';
                utcTimeline.appendChild(label);
            }

            // Draw event pins
            function drawPin(instant, color, label) {
                const x = timeToX(instant);

                // Pin line
                const pin = document.createElementNS('http://www.w3.org/2000/svg', 'line');
                pin.setAttribute('x1', x);
                pin.setAttribute('x2', x);
                pin.setAttribute('y1', timelineY - 25);
                pin.setAttribute('y2', timelineY);
                pin.setAttribute('stroke', color);
                pin.setAttribute('stroke-width', '3');
                utcTimeline.appendChild(pin);

                // Pin circle
                const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
                circle.setAttribute('cx', x);
                circle.setAttribute('cy', timelineY);
                circle.setAttribute('r', '6');
                circle.setAttribute('fill', color);
                utcTimeline.appendChild(circle);

                // Label
                const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                text.setAttribute('x', x);
                text.setAttribute('y', timelineY - 35);
                text.setAttribute('text-anchor', 'middle');
                text.setAttribute('fill', color);
                text.setAttribute('font-size', '12');
                text.setAttribute('font-weight', 'bold');
                text.textContent = label;
                utcTimeline.appendChild(text);
            }

            drawPin(sydInstant, '#ff6b6b', 'Sydney Flight');
            drawPin(sfInstant, '#4ecdc4', 'SF Now');

            // Draw delta bracket (correct)
            const sydX = timeToX(sydInstant);
            const sfX = timeToX(sfInstant);
            const leftX = Math.min(sydX, sfX);
            const rightX = Math.max(sydX, sfX);

            if (rightX - leftX > 5) { // Only draw if there's enough space
                const bracket = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                const bracketY = timelineY + 35;
                bracket.setAttribute('d', `M ${leftX} ${bracketY-5} L ${leftX} ${bracketY} L ${rightX} ${bracketY} L ${rightX} ${bracketY-5}`);
                bracket.setAttribute('stroke', '#3fb950');
                bracket.setAttribute('stroke-width', '2');
                bracket.setAttribute('fill', 'none');
                utcTimeline.appendChild(bracket);

                // Delta label
                const deltaLabel = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                deltaLabel.setAttribute('x', (leftX + rightX) / 2);
                deltaLabel.setAttribute('y', bracketY + 15);
                deltaLabel.setAttribute('text-anchor', 'middle');
                deltaLabel.setAttribute('fill', '#3fb950');
                deltaLabel.setAttribute('font-size', '10');
                deltaLabel.textContent = 'Δt (correct)';
                utcTimeline.appendChild(deltaLabel);
            }
        }

        function updateCalculations() {
            const sydDateStr = sydDate.value;
            const sydTimeStr = sydTime.value;

            if (!sydDateStr || !sydTimeStr || !sfNowInstant) {
                dtCorrect.textContent = 'Set both times first';
                dtNaive.textContent = 'Set both times first';
                offsetDiff.textContent = '—';
                sydReadout.textContent = 'Sydney: Set date/time above';
                sfReadout.textContent = 'San Francisco: Click "Use Now"';
                return;
            }

            // Convert Sydney local time to UTC instant
            const sydResult = localSydneyToInstant(sydDateStr, sydTimeStr);

            // Handle DST transitions
            if (sydResult.status === 'gap') {
                if (dstControls) dstControls.classList.add('show');
                if (dstMessage) {
                    dstMessage.textContent = `Time ${sydTimeStr} doesn't exist on ${sydDateStr} due to DST spring-forward.`;
                    if (sydResult.adjustedTime) {
                        dstMessage.textContent += ` Auto-adjusted to ${sydResult.adjustedTime}.`;
                    }
                }
                sydFlightInstant = sydResult.instant;
            } else if (sydResult.status === 'fold') {
                if (dstControls) dstControls.classList.add('show');
                if (dstMessage) {
                    dstMessage.textContent = `Time ${sydTimeStr} occurs twice on ${sydDateStr} due to DST fall-back. Using earlier occurrence.`;
                }
                sydFlightInstant = sydResult.instant;
            } else {
                if (dstControls) dstControls.classList.remove('show');
                sydFlightInstant = sydResult.instant;
            }

            if (!sydFlightInstant) {
                dtCorrect.textContent = 'Invalid Sydney time';
                dtNaive.textContent = 'Invalid Sydney time';
                return;
            }

            // Calculate correct delta (UTC instant subtraction)
            const correctDeltaMs = sfNowInstant - sydFlightInstant;
            dtCorrect.textContent = formatDuration(correctDeltaMs);

            // Calculate naive delta
            const naiveDeltaMs = calculateNaiveDelta(sydDateStr, sydTimeStr, sfNowInstant);
            dtNaive.textContent = formatDuration(naiveDeltaMs);

            // Calculate offset difference
            const sydOffset = getTimezoneOffsetHours(sydFlightInstant, 'Australia/Sydney');
            const sfOffset = getTimezoneOffsetHours(sfNowInstant, 'America/Los_Angeles');
            const offsetDifference = sfOffset - sydOffset;

            const sfOffsetStr = sfOffset >= 0 ? `+${sfOffset}` : `${sfOffset}`;
            const sydOffsetStr = sydOffset >= 0 ? `+${sydOffset}` : `${sydOffset}`;
            const diffStr = offsetDifference >= 0 ? `+${offsetDifference}` : `${offsetDifference}`;

            offsetDiff.textContent = `(${sfOffsetStr}h) − (${sydOffsetStr}h) = ${diffStr}h`;

            // Update local readouts
            sydReadout.textContent = `Sydney: ${formatLocalTime(sydFlightInstant, 'Australia/Sydney')}`;
            sfReadout.textContent = `San Francisco: ${formatLocalTime(sfNowInstant, 'America/Los_Angeles')}`;

            // Draw timeline
            drawTimeline(sydFlightInstant, sfNowInstant);
        }

        // Event handlers
        sfNowBtn.addEventListener('click', () => {
            sfNowInstant = Date.now(); // Store as epoch milliseconds
            sfNowReadout.textContent = new Intl.DateTimeFormat('en-US', {
                timeZone: 'America/Los_Angeles',
                month: '2-digit',
                day: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                timeZoneName: 'short'
            }).format(new Date(sfNowInstant));
            updateCalculations();
        });

        // DST demo button
        if (dstDemoBtn) {
            dstDemoBtn.addEventListener('click', () => {
                sydDate.value = '2025-10-05';
                sydTime.value = '02:30';
                updateCalculations();
            });
        }

        sydDate.addEventListener('change', updateCalculations);
        sydTime.addEventListener('change', updateCalculations);

        // Set default Sydney time
        if (!sydDate.value) sydDate.value = '2025-09-15';
        if (!sydTime.value) sydTime.value = '08:10';

        console.log('Flight vs Now timezone demo initialized');
    } catch (error) {
        console.error('Error initializing Flight vs Now demo:', error);
    }
}



// Update total slides on load
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('total-slides').textContent = slidesData.length;
    showSlide(0);
    
    console.log('Keyboard shortcuts:');
    console.log('→ or Space: Next slide');
    console.log('←: Previous slide');
    console.log('1-9: Jump to slide');
    console.log('Home: First slide');
    console.log('End: Last slide');
});
